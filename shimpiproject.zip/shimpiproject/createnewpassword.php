<!DOCTYPE html>
<html>
<head>
	<style>
		.btn
		{
			background-color: lightblue;
		}
		.btn:hover
		{
			 background-color: grey;
		}
		input[type=submit] 
		{
			background-color: #ff9900;
		}
		input[type=submit]:hover 
		{
 		 	background-color: #cc7a00;
		}
		input[type=email], select 
		{
			border-color: lightblue;
		}
	</style>
</head>
<body>
	<div>
		<center>
			<a href="index.php"><img src="http://localhost/shimpiproject/book_images/Logo.png" height="70" width="90" style="margin-left: -45px;text-decoration: none">
			<h3 style="margin-top: -50px;margin-left: 100px;">Sharvi.in</h3></a>
		</center><br>
		<center>
			<form style="border: 1px solid #d0e1e1; width: 25%; height: 250px" action="#" method="post">
				<table>
					<tr>
						<td><font style="font-size: 30px; font-family:Amazon Ember,Arial,sans-serif;" >Create new password</font>
							<br><font style="font-size: 15px; font-family:Amazon Ember,Arial,sans-serif;" >We'll ask for this password whenever you sign in</font></td>
					</tr>
					<tr>
						<td><br><font style="font-size: 20px; font-family:Amazon Ember,Arial,sans-serif;" >New Password</font></td>
					</tr>
					<tr>
						<td>
							<input type="password" name="email"  pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and atleast 8 or more characters" style="width: 250px;">
						</td>
					</tr>
					<tr>
						<td><br><font style="font-size: 20px; font-family:Amazon Ember,Arial,sans-serif;">Repeat Password</font></td>
					</tr>
					<tr>
						<td>
							<input type="password" name="email"  pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and atleast 8 or more characters" style="width: 250px;">
						</td>
					</tr>
					<tr>
						<td><br>
							<input type="submit" name="" value="Save changes and sign in" style="width: 300px;margin-left: -10px;height: 30px; cursor: pointer;">
						</td>
					</tr>
				</table>
			</form><br><br>
			<font style="font-size: 15px; font-family:Amazon Ember,Arial,sans-serif;margin-left: -250px">password tips:</font><br><br>	
			<li style="margin-left:-94px ">Must contain at least one number</li>
			<li>Must be one uppercase and one lowercase letter </li>
			<li style="margin-left:-123px ">Atleast 8 or more characters</li>
		</center>
	</div>
</body>
</html>