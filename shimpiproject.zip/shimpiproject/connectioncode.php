<?php
	$host="localhost:3306";
	$username="root";
	$password="";
	$db="bookstoredb";
	$conn= mysqli_connect($host,$username,$password,$db);
	if (!$conn) {
		die("".mysqli_connect_error());
	}
?>
