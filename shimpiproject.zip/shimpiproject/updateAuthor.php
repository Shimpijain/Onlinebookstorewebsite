<?php
	include("connectioncode.php");
?>
<?php
	$succMsg=$failMsg="";
	$author=$_POST["h1"];
	$id=$_POST["h3"];
	$fn = $_POST["h2"];
	//echo "$author";
	//echo "$id";
	$sql= "update addauthor set authorname=\"$author\", filename=\"$fn\" where id=\"$id\"";	
	if(mysqli_query($conn,$sql))
	{
		$succMsg="Successfully updated";
		header("Location:view_editAuthor.php?succMsg=$succMsg&failMsg=$failMsg");
	}
	else
	{
		$failMsg= "Updation Failure";
		header("Location:view_editAuthor.php?succMsg=$succMsg&failMsg=$failMsg");
	}
	mysqli_close($conn);
?>