<?php                               
include("connectioncode.php");
?>
<?php
$menu1=$_GET["menu1"];
$menu2=$_GET["menu2"];
$menu3=$_GET["menu3"];
$menu4=$_GET["menu4"];
$bookname=$_GET["bookname"];
$bookno=$_GET["bookno"];
$bookprice=$_GET["bookprice"];
$imagename=$_GET["imagename"];
$uploadOk=$_GET["uploadOk"];
	
	if($uploadOk==1){
				$dupsql="select * from addbook where categoryid=\"$menu1\" and bookname=\"$bookname\"";

          		$vals = mysqli_query($conn, $dupsql);

          		if(mysqli_num_rows($vals)>0)
          		{
            		$msgerr = "Book is already exixts.";
            		header("Location:addbook.php?uploadOk=$uploadOk&imagename=$imagename&menu1=$menu1&menu2=$menu2&menu3=$menu3&menu4=$menu4&bookname=$bookname&bookno=$bookno&bookprice=$bookprice&msg=$msg");
          		}
          		else
          		{
					if ($menu1!="0" && $menu2!="0" && $menu3!="0" && $menu4!="0" && !empty($bookname) && !empty($bookno) && !empty($imagename) && !empty($bookprice)) 
					{
						$sql="insert into addbook(categoryid,authorid,publisherid,language,bookname,bookno,bookprice,imagename)values(\"$menu1\",\"$menu2\",\"$menu3\",\"$menu4\",\"$bookname\",\"$bookno\",\"$bookprice\",\"$imagename\")";
						if(mysqli_query($conn,$sql))
						{
							$msg = "book added successfully";
							$menu1="";
							$menu2="";
							$menu3="";
							$menu4="";
							$bookname="";
							$bookno="";
							$bookprice="";
							$imagename="";
							header("Location:addbook.php?uploadOk=$uploadOk&imagename=$imagename&menu1=$menu1&menu2=$menu2&menu3=$menu3&menu4=$menu4&bookname=$bookname&bookno=$bookno&bookprice=$bookprice&msg=$msg");
						}
						else
						{
							$msgerr = "book does not add successfully";
							$menu1="";
							$menu2="";
							$menu3="";
							$menu4="";
							$bookname="";
							$bookno="";
							$bookprice="";							
							header("Location:addbook.php?uploadOk=$uploadOk&imagename=$imagename&menu1=$menu1&menu2=$menu2&menu3=$menu3&menu4=$menu4&bookname=$bookname&bookno=$bookno&bookprice=$bookprice&msgerr=$msgerr");
						}
					} 
					else
					{
							$msgerr = "Please fill all the required field.";		
							header("Location:addbook.php?uploadOk=$uploadOk&imagename=$imagename&menu1=$menu1&menu2=$menu2&menu3=$menu3&menu4=$menu4&bookname=$bookname&bookno=$bookno&bookprice=$bookprice&msgerr=$msgerr");
					}
				}
	}
	else{
		$msgerr = "Please fill all the required field.";		
		header("Location:addbook.php?uploadOk=$uploadOk&imagename=$imagename&menu1=$menu1&menu2=$menu2&menu3=$menu3&menu4=$menu4&bookname=$bookname&bookno=$bookno&bookprice=$bookprice&msgerr=$msgerr");
	}	
mysqli_close($conn);
?>