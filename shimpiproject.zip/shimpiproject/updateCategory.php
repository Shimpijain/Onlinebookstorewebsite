<?php
	include("connectioncode.php");
?>
<?php
	$succMsg=$failMsg="";
	$category=$_POST["h1"];
	$id=$_POST["h3"];
	$fn = $_POST["h2"];
	//echo "$category";
	//echo "$id";
	$sql= "update addcategory set categoryname=\"$category\", filename=\"$fn\" where id=\"$id\"";	
	if(mysqli_query($conn,$sql))
	{
		$succMsg="Successfully updated";
		header("Location:view_editCategory.php?succMsg=$succMsg&failMsg=$failMsg");
	}
	else
	{
		$failMsg= "Updation Failure";
		header("Location:view_editCategory.php?succMsg=$succMsg&failMsg=$failMsg");
	}
	mysqli_close($conn);
?>