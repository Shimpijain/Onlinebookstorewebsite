<?php
session_start();
 
if(!isset($_SESSION["userid"])){ //If session not registered
	header("location:login.php"); // Redirect to login.php page
}
else
{
	$now=time();
	if($now > $_SESSION['expire'])
	{
		session_destroy();
		header("Location:login.php");
	}
}

?>
<!DOCTYPE html>
<html>
<head>	
<title>Welcome - Book Store</title>
<meta name="viewport"
	content="width=device-width,initial-scale=1">

<link rel="stylesheet" type="text/css" href="css/style.css"/>
<link rel="stylesheet" type="text/css" href="css/nitin.css"/>
<link rel="stylesheet" type="text/css" href="css/menu.css"/>

<script type="text/javascript">
	window.history.forward();
	function noBack(){ window.history.forward(); }
</script>
<style>
	.main_contain
	{
		position: absolute;
		width: 1400px;
	}
</style>
</head>
<body onload="noBack();">
	<?php
		$msgerr="";
		$category="";
		$author="";
		$publisher="";
		$menu1 = "";
		$menu2 = "";
		$menu3 = "";
		$menu4 = "";
		$bookname = "";
		$bookno = "";
		$bookprice="";	

	?>
	<div class="main_contain">
	<div class="header" style="background-color: purple;width:1366px">
		<img src="http://localhost/shimpiproject/book_images/Logo.png"  height="74" width="140" alt="logo" align="absmiddle"/><B style="margin-left:20px;"><font face="chiller" size="32" color="lightblue">Admin View Page</font></B>
	</div>
	<div style="width:100%;float:left;">
	<div class="main_common" style="float:left;width:97%;height:360px;margin-left:15px">
	<div style="width:92%;margin:auto;">
		<div class="login_div">
			<div align="right">
				<a href="index.php"><img src="book_images/home.jpg" height="50" width="50" alt="home" title="Home" align="absmiddle"></a>&nbsp;&nbsp;&nbsp;&nbsp;||&nbsp;&nbsp;&nbsp;&nbsp;<B><font face="Times New Roman" size="4">Welcome:</font>&nbsp;<font face="Times New Roman" size="4" color="#000099"><?php echo $_SESSION["userid"];?></font></B>&nbsp;&nbsp;&nbsp;&nbsp;||&nbsp;&nbsp;&nbsp;&nbsp;<a href="logout.php"><b><font size="3">Logout</font></b></a>&nbsp;&nbsp;&nbsp;&nbsp;
			</div>
			<div align="center">
					<b><font face="calibiri" size="+2" color="#000099">Admin Tasks</font></b><br>
					<div align="right">
						<form action="">
							<table border=0>
								<tr>							
								<td align="center" valign="middle">
									<input type="text" name="searchText" size="40" placeholder="Type Username or Contact number"/><br>		
								</td>
							<td align="center" valign="middle">
								<input type="submit" value="Search" onclick="callAction()"/>
							</td>
						</tr>
					</table>
				</form>
				</div>	
	

			<nav class="menu" style="height: 210px">
			<ul class="main1" style="width:100%">				
			  <li><a href="index.php">Home</a></li>  
			  <li><a href="#" class="book">Books</a>
			  	<ul class="house1">  		
			  		<li><a href="addbook.php?uploadOk=0&msgerr=&menu1=&menu2=&menu3=&menu4=&bookname=&bookno=$bookprice=">Add book</a></li>
					<li><a href="#">Book Stock</a></li>
			  	</ul>
			</li>
			</li>
			<li><a href="#">Mail/Message Sending</a></li>  
			</ul>
			</nav>

					<div style="width:84%;float:right; margin: auto; padding: auto;">					
							 <ul class="dash_board" style="margin-left: -20px;width:1190px;float:left;">
							 	<li>
							 		<a href="addcategory.php?uploadOk=0&msgerr=<?php echo $msgerr;?>&category=<?php echo $category;?>&fname=<?php $fname; ?>">
							 			<img src="http://localhost/shimpiproject/book_images/category.jpg" width="70px" height="70px">
							 		</a><br>
							 		<b><font face="calibiri" size="2.5">Add Category</font></b><br><br>
							 	</li>
							 	<li>
							 		<a href="addauthor.php?uploadOk=0&msgerr=<?php echo $msgerr;?>&author=<?php echo $author;?>&fname=<?php $fname; ?>">
							 			<img src="http://localhost/shimpiproject/book_images/author.png" width="70px" height="70px">
							 		</a><br>
							 		<b><font face="calibiri" size="2.5">Add Author</font></b><br><br>
							 	</li>
							 	<li>
							 		<a href="addpublisher.php?uploadOk=0&msgerr=<?php echo $msgerr;?>&publisher=<?php echo $publisher;?>&fname=<?php $fname; ?>">
							 			<img src="http://localhost/shimpiproject/book_images/publisher.jpg" width="70px" height="70px">
							 		</a><br>
							 		<b><font face="calibiri" size="2.5">Add Publisher</font></b><br><br>
							 	</li>
							 	<li><a href="addbook.php?uploadOk=0&msgerr=<?php echo $msgerr;?>&menu1=<?php echo $menu1;?>&menu2=<?php echo $menu2;?>&menu3=<?php echo $menu3;?>&menu4=<?php echo $menu4;?>&bookname=<?php echo $bookname;?>&bookno=<?php echo $bookno;?>&bookprice=<?php echo $bookprice;?>">
							 			<img src="http://localhost/shimpiproject/book_images/cartoon.png" height="70px" width="70px">
							 		</a><br>
							 		<b><font face="calibiri" size="2.5">Add Books</font></b><br><br>
							 	</li>		
								<li>
									<a href="Feedback.php">
										<img src="http://localhost/shimpiproject/book_images/msg.png" height="70px" width="150px">
									</a><br>
									<b><font face="calibiri" size="2.5">FeedBack</font></b><br><br>
								</li>
								<li>
									<a href="bookstock.php?msgerr=">
										<img src="http://localhost/shimpiproject/book_images/book.png" height="70px" width="70px">
									</a><br>
									<b><font face="calibiri" size="2.5">Book Stock</font></b><br><br>
								</li>
							</ul>
											
					</div>		
					<br><br>				
			</div>
			</div>
		</div>
	</div>
	</div>
	<div class="footer" style="height: 80px;width: 1366px">
		<div class="footerLogo1">
			Developed by
		</div>
		<div class="footerLogo2">
			<img src="http://localhost/shimpiproject/book_images/Logo.png">		
		</div>
	</div>
</div>
</body>
</html>