<?php
session_start();
if(!isset($_SESSION["userid"])){ //If session not registered
	header("location:login.php"); // Redirect to login.php page
}
else
{
	$now=time();
	if($now > $_SESSION['expire'])
	{
		session_destroy();
		header("Location:login.php");
	}
}
include("connectioncode.php");
 ?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title>FeedBack</title>
	<link rel="stylesheet" type="text/css" href="css/style.css"/>
	<style>
.btn
		{
			text-decoration: none;
			border: none;
 			outline: 0;
  			padding: 6px;
  			color: white;
 			background-color: #000;
 			text-align: center;
 			cursor: pointer;
 			font-size: 14px;
 			
		}
		.success{
			color: green;
		}
		.error{
			color:red;
		}
	</style>
</head>
<body>
<div class="main_contain">
	<div class="header" style="background-color: purple">
		<img src="http://localhost/shimpiproject/book_images/Logo.png"  height="74" width="140" alt="logo" align="absmiddle"/><B style="margin-left:20px;"><font face="calibiri" size="+3" color="#FFFFFF">Admin Home Page</font></B>
	</div>
	<div class="main_addCategory">
		<div class="login_div">
			<div align="right">				
				<a href="adminhomepage.php"><img src="http://localhost/shimpiproject/book_images/home.jpg" height="50" width="50" alt="home" title="Home" align="absmiddle"></a>&nbsp;&nbsp;&nbsp;&nbsp;||&nbsp;&nbsp;&nbsp;&nbsp;<a href="adminhomepage.php"><img src="http://localhost/shimpiproject/book_images/bk.png" height="50" width="70" alt="back" title="Go Back One Page" align="absmiddle"></a>&nbsp;&nbsp;&nbsp;&nbsp;||&nbsp;&nbsp;&nbsp;&nbsp;<B><font face="Times New Roman" size="4">Welcome:</font></B><font face="Times New Roman" size="4" color="#000099"><?php echo $_SESSION["userid"];?>&nbsp;&nbsp;&nbsp;&nbsp;||&nbsp;&nbsp;&nbsp;&nbsp;<a href="logout.php"><b><font size="3">Logout</font></b></a>&nbsp;&nbsp;&nbsp;&nbsp;								
			</div>
			<div align="center">
				<b><font face="calibiri" size="+2" color="#000099">FeedBack</b></font></b><br><br><br><br>
						
						<table border="1" width="800">
							<?php
								$sql ="select * from feedback";
								$result= mysqli_query($conn, $sql);
								if(mysqli_num_rows($result)<0){
							?>
							<tr>
								<td align="center" valign="middle" colspan="4">
									<b><font size="3" face="Times New Roman">No FeedBack Available</font><br><br><br><br></b>
								</td>
							</tr>
							<?php
								}
								else
								{
									?>
									<tr>
										<th align="center" valign="middle">
											<b><font face="Times New Roman" size="3">S. No.</font></b>
										</th>
										<th align="center" valign="middle">
											<b><font face="Times New Roman" size="3">email id</font></b>
										</th>
										<th align="center" valign="middle">
											<b><font face="Times New Roman" size="3">Comment</font></b>
										</th>
										<th>
											&nbsp;
										</th>
									</tr>
							<?php
									$i=0;
									while($row=mysqli_fetch_array($result))
									{
										$id= $row['id'];
										$email= $row['email'];
										$comment=$row['comment'];
							?>			
									<tr>
										<td align="center" valign="middle">
											<font face="Times New Roman" size="3"><?php echo ++$i ?></font>
										</td>
										<td align="center" valign="middle">
											<font face="Times New Roman" size="3"><?php echo $email ?></font>
										</td>
										<td align="center" valign="middle">
											<font face="Times New Roman" size="3"><?php echo $comment ?></font>
										</td>
									</tr>
									<?php
									}
								}
								?>

						</table>
				<?php
				mysqli_close($conn);
				?>	
				</form><br><br><br><br>								
			</div>
		</div>
	</div>
	<br><br><br><br><br>
	<br><br>
	
	<div class="footer">
		<div class="footerLogo1">
			Developed by
		</div>
		<div class="footerLogo2">
			<img src="http://localhost/shimpiproject/book_images/Logo.png">		
		</div>
	</div>
</body>
</html>