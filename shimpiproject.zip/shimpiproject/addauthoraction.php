<?php
include("Connectioncode.php");
?>
<?php

function filtername($field)
  {
    $field=filter_var(trim($field),FILTER_SANITIZE_STRING);
    if(filter_var($field,FILTER_VALIDATE_REGEXP,array("options"=>array("regexp"=>"/^[a-zA-Z\s]+$/"))))
    {
      return $field;
    }
    else
    {
      return FALSE;
    }
  }


$fname=test_input($_GET["filename"]);
$author=filterName(test_input($_GET["author"]));

	if ($author==FALSE)
		{
			$msgerr="Please enter a correct value";
		}
	else
	{

		 $dupsql="select * from addauthor where authorname=\"$author\"";
          $vals = mysqli_query($conn, $dupsql);          
          if(mysqli_num_rows($vals)>0)
          {
            $msgerr = "Author is already exixts.";
            header("Location:addauthor.php?uploadOk=0&fname=$fname&author=$author&msgerr=$msgerr");
          }

           else
           {

				if (!empty($fname) && !empty($author)) 
				{
					$sql="insert into addauthor(authorname,filename)values(\"$author\",\"$fname\")";
					if(mysqli_query($conn,$sql))
					{
						$msg = "Author added successfully";
						$fname="";
						$author="";
						header("Location:addauthor.php?uploadOk=1&fname=$fname&author=$author&msg=$msg");
					}
					else
					{
						$msgerr = "Author does not add successfully";
						header("Location:addauthor.php?uploadOk=0&fname=$fname&author=$author&msgerr=$msgerr");
					}
				}
			}
		}

function test_input($data)
{
	$data= trim($data);
	$data= stripcslashes($data);
	$data= htmlspecialchars($data);
	return $data;
}
mysqli_close($conn);
?>