<?php 
	session_start();
	include("connectioncode.php");
?>
<!DOCTYPE html>
<html>
<head>
	<title> Buy Now</title>
	<style type="text/css">
		input[type=submit]
		{
			width:250px;
			height: 35px;
		}
		input[type=submit]:hover
		{
			background-color: lightblue;
		}
	</style>
	<?php
		$mailid=$fullname=$contactno=$address=$state=$city=$pincode=$orderid="";
		$bookname="";
		$bookprice=0;
		if(isset($_SESSION["loggedmail"]))
		{
			$mailid = $_SESSION["loggedmail"];
		}

		$sql="select * from userinfo where emailid=\"$mailid\"";
		$result=mysqli_query($conn,$sql);
		if(mysqli_num_rows($result)>0){
			while($row=mysqli_fetch_array($result)){
				$fullname = $row["fullname"];
				$char = substr($fullname, 0,2);
				$contactno = $row["contactno"];
				$address = $row["address"];
				$state = $row["state"];
				$city = $row["city"];
				$pincode = $row["pincode"];
			}
		}	

		$sql1="select * from addtocart where emailid=\"$mailid\"";
		$result1=mysqli_query($conn,$sql1);		
	?>
</head>
<body bgcolor="#e6ffe6">
	<?php
		$mailid=$paymentmethod=$bookno=$orderdate=$status="";
		$msgerr=$msg="";
		$pres=0;

		if ($_SERVER["REQUEST_METHOD"]=="POST")
		{	
			$sumPrice=0;
			$paymentmethod=$_POST["cod"];
			if($paymentmethod=="cash"){
				$status="due";
			}
			else{
				$status="paid";
			}
			$orderid = "#ODR".$char.rand();
			$_SESSION["orderno"]=$orderid;

			if(isset($_SESSION["loggedmail"]))
			{
				$mailid = $_SESSION["loggedmail"];
			}

			$getsql="select * from addtocart where emailid=\"$mailid\"";
			$getres=mysqli_query($conn,$getsql);	
			if(mysqli_num_rows($getres)>0){
					while($row2=mysqli_fetch_array($getres))
					{
						$bookno=$row2["bookno"];
						$bookprice=$row2["bookprice"];
						$sumPrice=$sumPrice+$bookprice;
						$sql2="insert into purchaseitem(orderid,emailid,bookno,bookprice,paymentmethod) values(\"$orderid\",\"$mailid\",\"$bookno\",\"$bookprice\",\"$paymentmethod\")";
				 		$pres = mysqli_query($conn,$sql2);
				    		
					}

					if($pres==1){
						$orderdate=date("l jS \of F Y");
										
						$sql3="insert into buynow(orderid,emailid,totalprice,orderdate,status)values(\"$orderid\",\"$mailid\",\"$sumPrice\",\"$orderdate\",\"$status\")";
						if(mysqli_query($conn,$sql3)){
							$dsql = "delete from addtocart where emailid=\"$mailid\"";
							if(mysqli_query($conn,$dsql)){
								header("Location:ordersubmit.php");
							}	
						}
					}
			}					
		}
		
?>
	<center>
		<a href="index.php"><img src="http://localhost/shimpiproject/book_images/Logo.png" height="90" width="70"></a>
		<form style="border:1px solid black;width: 450px;height:auto;line-height: 40px;background-color: #b3cccc" method="POST">
			<p><font><?php echo $msgerr; ?></font></p>
			<p><font color="black"><?php echo $msg; ?></font></p>
			<table>
				<tr>
					<td>
						<font size="5">Shipping To:</font>
					</td>
				</tr>
				<tr style="background-color: white;">
					<td>
						<?php echo $fullname; ?><br>Address:<?php echo $address; ?><br>State:&nbsp;<?php echo $state; ?>&nbsp;&nbsp;City:<?php echo $city; ?>&nbsp;&nbsp;Contact No:<?php echo $contactno; ?><br><?php echo $pincode; ?>
					</td>
				</tr>
				<tr>
					<td><br>
						<div style="background-color: black;height: 1px;width: 449px;margin-left: -5px"></div>
					</td>
				</tr>
				<tr>
					<td><br>
						<font size="5">Payment Method</font>
					</td>
				</tr>
				<tr style="background-color: white;">
					<td>Pay On Delivery</td>
					<td>
						<input type="radio" name="cod" value="cash" style="margin-left: -100px" required>
					</td>
				</tr>
				<tr style="background-color: white;">
					<td>Paytm(At This time not Available)</td>
					<td>
						<input type="radio" name="paytm" disabled="" style="margin-left: -100px">
					</td>
				</tr>
				<tr style="background-color: white;">
					<td>Credit Card(At This time not Available)</td>
					<td>
						<input type="radio" name="card" disabled="" style="margin-left: -100px">
					</td>
				</tr>
				<tr>
					<td><br>
						<div style="background-color: black;height: 1px;width: 450px;margin-left: -5px"></div>
					</td>
				</tr>
				<tr>
					<td>
						<font size="5">Order Summery:</font>
						<font>
							<?php echo $orderid;?>
						</font>
					</td><br>
				</tr>
				<?php
				if(mysqli_num_rows($result1)>0)
				{	
					$sum=0;
					while($row3=mysqli_fetch_array($result1))
					{
						$bkname=$row3["bookname"];
						$bkprice=$row3["bookprice"];
				?>
						
						<tr style="background-color: white;">
							<td>
								<font><?php echo $bkname;?></font>
								<font style="margin-left: 290px"><?php echo $bkprice;?>&#8377;</font>
							</td>
						</tr>
				<?php
						$sum=$sum+$bkprice;						
					}
					$sum=$sum+50;
				}
				?>				
				<tr style="background-color: white;">
					<td>
						<font>Shipping Charge:</font>
						<font style="margin-left: 300px">50&#8377;</font>
					</td>
				</tr>
				<tr style="background-color: white;">
					<td>
						Total:
						<?php echo $sum;?>
					</td>
					
				</tr>
				<tr>
					<td><br>
						<div style="background-color: black;height: 1px;width: 450px;margin-left: -5px"></div>
					</td>
				</tr>
				<tr>
					<td>
						<center><input type="submit"  value="Proceed Order"></center>
					</td>
				</tr>
			</table>
		</form>
	</center>
</body>
</html>