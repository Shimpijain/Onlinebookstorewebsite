<html><head><title></title></head>
<body>
<button id="btnfile"> 
 <img src='".$cfet['productimage']."' width='50' height='40'>
</button> 
<div class="wrapper"> //set wrapper `display:hidden`
     <input type="file" id="uploadfile" /> 
</div>
<script>
$("#btnfile").click(function () {
    $("#uploadfile").click();
});
</script>
</body>
</html>