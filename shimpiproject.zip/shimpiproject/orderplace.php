<?php
	session_start();
	include("connectioncode.php");
?>
<?php
	$msg=$msgerr="";
	$categid=$authorid=$publisherid=$language=$bookname=$bookno=$bookprice=$imagename=$mailid="";

	$msg=$_GET["msg"];
	$msgerr=$_GET["msgerr"];
	$bookno=$_GET["bookno"];	
	if(isset($_SESSION["loggedmail"])){
		$mailid = $_SESSION["loggedmail"];
	}

		$categid=$_GET['categid'];
		$authorid=$_GET['authorid'];
		$publisherid=$_GET['publisherid'];
		$language=$_GET['language'];
		$bookname=$_GET['bookname'];
		$bookprice=$_GET['bookprice'];
		$imagename=$_GET['imagename'];

		$dupsql = "select * from addtocart where emailid =\"$mailid\" and bookno=\"$bookno\"";
		 $dupres = mysqli_query($conn, $dupsql);           
          if(!(mysqli_num_rows($dupres)>0))
          {           		  

		    	$sql="insert into addtocart(emailid,categoryid,authorid,publisherid,language,bookname,bookno,bookprice,imagename) values(\"$mailid\",\"$categid\",\"$authorid\",\"$publisherid\",\"$language\",\"$bookname\",\"$bookno\",\"$bookprice\",\"$imagename\")";
		 		if(mysqli_query($conn,$sql))
		    	{
		            $msg = "book added in cart successfully";		                   
				}
			}
    ?>
<!DOCTYPE html>
<html>
<head>
	<title>Order Place</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

	<style type="text/css">
		.btn
		{
			width: 150px;
			height: 30px;
			background-color: #ff751a;
			cursor: pointer;
		}
		.btn:hover
		{
			background-color: #993d00;
		}
		input[type=text]
		{
			width: 350px;
			height: 30px;
		}
		input[type=numeric]
		{
			width: 350px;
			height: 30px;
		}
		.submit
		{
			background-color: skyblue;
			cursor: pointer;
			text-decoration: none;
			border:7px solid lightblue;
		}
		.submit:hover
		{
			background-color: gray;
			cursor: pointer;
		}
	</style>
</head>
<body style="background-color:#cceeff">
	<?php
		$fullname=$contactno=$address=$state=$city=$pincode="";
		$flag=false;
		$addsql = "select * from userinfo where emailid=\"$mailid\"";
		$addres = mysqli_query($conn,$addsql);
		if(mysqli_num_rows($addres)>0){
			$flag=true;
			while($adrow=mysqli_fetch_array($addres)){
				$fullname = $adrow["fullname"];
				$contactno = $adrow["contactno"];
				$address = $adrow["address"];
				$state = $adrow["state"];
				$city = $adrow["city"];
				$pincode = $adrow["pincode"];
			}
		}
		else{
			$flag=false;
			$fullname="";
			$contactno="";
			$address="";
			$state="";
			$city="";
			$pincode="";
		}
	?>
    <a href="index.php" style="text-decoration: none;"><img src="http://localhost/shimpiproject/book_images/Logo.png" height="50" width="70" style="margin-left: 600px">ShraviBookStore</a>
<br><br><center>
	<p><font size="3" face="times new roman"><?php echo $msg;?></font></p>
	<p><font size="3" face="times new roman"><?php echo $msgerr;?></font></p>
    <form style="border:1px solid gray;width: 500px;height: 560px" action="orderplaceaction.php?bookno=<?php echo $bookno;?>&categid=<?php echo $categid;?>&authorid=<?php echo $authorid;?>&publisherid=<?php echo $publisherid;?>&language=<?php echo $language;?>&bookname=<?php echo $bookname;?>&bookprice=<?php echo $bookprice;?>&imagename=<?php echo $imagename;?>&msg=&msgerr=" method="POST">
    	<input type="hidden" name="status" value="<?php echo $flag;?>">
    	<table style="margin-top: -250px">
    		<font size="5" color="#800000">Place Order User Details</font><br><br>
    		<tr>
    			<td>Full Name:</td><br><br>
    			<td>
    				<input type="text" name="fullname" placeholder="Enter Your Fullname" value="<?php echo $fullname;?>" required>
    			</td><br>
    		</tr>
    		<tr>
    			<td>Contact No.:</td><br>
    			<td>
    				<input type="text" name="contactno" value="<?php echo $contactno;?>" placeholder="Enter Your Contact No." maxlength="10" required>
    			</td><br>
    		</tr>
    		<tr>
    			<td>Address:</td><br>
    			<td>
    				<textarea cols="40" rows="5" placeholder="Enter Your Address" name="address" required><?php echo $address;?></textarea>
    			</td><br>
    		</tr>
    		<tr>
    			<td>State:</td><br>
    			<td><br>
    				<input type="text" name="state" value="<?php echo $state;?>" placeholder="Enter Your State."  required>
    			</td><br>
    		</tr>
    		<tr>
    			<td>City:</td><br>
    			<td>
    				<input type="text" name="city" value="<?php echo $city;?>" placeholder="Enter Your City." required>
    			</td><br>
    		</tr>
    		<tr>
    			<td>Pincode:</td><br>
    			<td>
    				<input type="text" name="pincode" value="<?php echo $pincode;?>" placeholder="Enter Your Pincode." required>
    			</td><br>
    		</tr>
    		<tr>
    			<td>&nbsp;</td>
    			<td><br>
    				<input type="submit" value="Submit" class="submit">
    			</td><br>
    		</tr>	
    	</table>
    </form>
</center>
<?php
	mysqli_close($conn);
?>
</body>
</html>