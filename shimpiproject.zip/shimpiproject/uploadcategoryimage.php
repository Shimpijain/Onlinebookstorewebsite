<?php
session_start();
if(!isset($_SESSION["userid"])){ //If session not registered
header("location:login.php"); // Redirect to login.php page
}
else
{
	$now=time();
	if($now > $_SESSION['expire'])
	{
		session_destroy();
		header("Location:login.php");
	}
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title>Upload Image</title>
	<link rel="stylesheet" type="text/css" href="css/style.css"/>
	<style>
		.btn
		{
			text-decoration: none;
			border: none;
 			 outline: 0;
  			padding: 12px;
  			color: white;
 			background-color: #000;
 			text-align: center;
 			cursor: pointer;
			width: 50%;
 			font-size: 18px;
		}

		.success{
			color: green;
		}
		.error{
			color:red;
		}
</style>
</head>
<body>
<?php
$msg=$msgerr=$fname="";
$id = $_GET["h3"];
if($id==null){
	$id="";
}
$uploadOk=$_GET["uploadOk"];
if($uploadOk==0){
	$msgerr=$_GET["msgerr"];
}
else{
	$msg = $_GET["msg"];
	$fname = $_GET["fname"];
}
?>	
	<div class="main_contain">
	<div class="header" style="background-color: purple">
		<img src="http://localhost/shimpiproject/book_images/Logo.png"  height="74" width="140" alt="logo" align="absmiddle"/><B style="margin-left:20px;"><font face="calibiri" size="+3" color="#FFFFFF">Admin Home Page</font></B>
	</div>
	<div class="main_addCategory">
		<div class="login_div">
			<div align="right">
				<a href="#"><img src="http://localhost/shimpiproject/book_images/home.jpg" height="50" width="50" alt="home" title="Home" align="absmiddle"></a>&nbsp;&nbsp;&nbsp;&nbsp;||&nbsp;&nbsp;&nbsp;&nbsp;<a href="view_editCategory.php?succMsg=&failMsg="><img src="http://localhost/shimpiproject/book_images/bk.png" height="50" width="70" alt="back" title="Go Back One Page" align="absmiddle"></a>&nbsp;&nbsp;&nbsp;&nbsp;||&nbsp;&nbsp;&nbsp;&nbsp;<B><font face="Times New Roman" size="4">Welcome:</font>&nbsp;&nbsp;<font face="Times New Roman" size="4"><?php echo $_SESSION["userid"];?></font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			</div>
			<div align="center">
				<b><font face="calibiri" size="+2" color="#000099">Upload Image</b></font></b><br><br><br><br>
				<p><span class="success"><b><font face="calibiri" size="+1"><?php echo $msg; ?></b></font></span></p>
				<p><span class="error"><b><font face="calibiri" size="+1"><?php echo $msgerr; ?></font></b></span></p>
				<form action="uploadimage.php" method="post" enctype="multipart/form-data">
					<input type="hidden" name="h3" value="<?php echo $id; ?>">
					<table border=0>
						<tr>
							<td align="right" valign="middle"><font font size="3" face="Times New Roman">Select Images:</font><br><br> </td>
							<td align="left" valign="middle"><input type="file" name="image" multiple required><br><br></td>
							<td align="left" valign="middle"><input type="submit" value="Upload"><br><br></td>
						</tr>
						<tr>
							<td align="right" valign="middle">
								<font font size="3" face="Times New Roman">Uploaded image Name:</font><br><br>
							</td>							
							<td align="left" valign="middle" colspan=2>
								<input type="text" name="filename" value="<?php echo $fname;?>" size="30" disabled/><br><br>
							</td>							
						</tr>
						<tr>							
							<td>
								&nbsp;
							</td>	
							<td align="left" valign="middle" colspan=2>
								<a href="updateimage.php?fname=<?php echo $fname;?>&h3=<?php echo $id; ?>" class="btn">Add Image</a>
							</td>							
						</tr>
						</table>
				</form><br><br><br><br>
			</div>
		</div>
	</div>
	<div class="footer">
		<div class="footerLogo1">
			Developed by
		</div>
		<div class="footerLogo2">
			<img src="http://localhost/shimpiproject/book_images/Logo.png">		
		</div>
	</div>
</div>
</body>
</html>