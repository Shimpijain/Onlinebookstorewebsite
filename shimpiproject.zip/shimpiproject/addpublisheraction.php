<?php
include("Connectioncode.php");
?>
<?php

function filtername($field)
  {
    $field=filter_var(trim($field),FILTER_SANITIZE_STRING);
    if(filter_var($field,FILTER_VALIDATE_REGEXP,array("options"=>array("regexp"=>"/^[a-zA-Z\s]+$/"))))
    {
      return $field;
    }
    else
    {
      return FALSE;
    }
  }

$fname=test_input($_GET["filename"]);
$publisher=filterName(test_input($_GET["publisher"]));


	if ($publisher==FALSE)
		{
			$msgerr="Please enter a correct value";
		}

	else
	{

		$dupsql="select * from addpublisher where publishername=\"$publisher\"";
          $vals = mysqli_query($conn, $dupsql);          
          if(mysqli_num_rows($vals)>0)
          {
            $msgerr = "Publisher is already exixts.";
            header("Location:addpublisher.php?uploadOk=0&fname=$fname&publisher=$publisher&msgerr=$msgerr");
          }

           else{

					if (!empty($fname) && !empty($publisher)) 
					{
						$sql="insert into addpublisher(publishername,filename)values(\"$publisher\",\"$fname\")";
						if(mysqli_query($conn,$sql)){
							$msg = "Publisher added successfully";
							$fname="";
							$publisher="";
							header("Location:addpublisher.php?uploadOk=1&fname=$fname&publisher=$publisher&msg=$msg");
						}
						else{
							$msgerr = "Publisher does not add successfully";
							header("Location:addpublisher.php?uploadOk=0&fname=$fname&publisher=$publisher&msgerr=$msgerr");
						}
					}
				}
			}


function test_input($data)
{
	$data= trim($data);
	$data= stripcslashes($data);
	$data= htmlspecialchars($data);
	return $data;
}
mysqli_close($conn);
?>