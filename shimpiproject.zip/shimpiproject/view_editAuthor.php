<?php
session_start();
if(!isset($_SESSION["userid"])){ //If session not registered
header("location:login.php"); // Redirect to login.php page
}
else
{
	$now=time();
	if($now > $_SESSION['expire'])
	{
		session_destroy();
		header("Location:login.php");
	}
}
?>
<?php
include("connectioncode.php");
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>View/Edit</title>
<link rel="stylesheet" type="text/css" href="css/style.css"/>
<script type="text/javascript">

function changesDone(obj1, obj2, obj3){
	document.viewForm.h1.value = obj1.value;
	document.viewForm.h2.value = obj2.value;
	document.viewForm.h3.value = obj3;
	document.viewForm.action = "updateAuthor.php";
	document.viewForm.submit();
}

function uploadFile(obj1, obj2, obj3){
	document.viewForm.h1.value = obj1.value;
	document.viewForm.h2.value = obj2.value;
	document.viewForm.h3.value = obj3;	
	document.viewForm.action = "uploadauthorimage.php?uploadOk=0&msgerr=&msg=&h3="+obj3;
	document.viewForm.submit();
}
 
function delete_author(obj1){
	var agree = confirm('Are you absolutely sure you want to delete?');
	if(agree){
		document.viewForm.h1.value = obj1;
		document.viewForm.action = "deleteAuthor.php";
		document.viewForm.submit();
		true;
	}
	else{
		false;
	}
}
</script>
</head>
<body>
<?php
$succMsg = $_GET["succMsg"];
if($succMsg==null){
	$succMsg="";
}

$failMsg = $_GET["failMsg"];
if($failMsg==null){
	$failMsg="";
}

?>
<div class="main_contain">
	<div class="header">
		<img src="http://localhost/shimpiproject/book_images/Logo.png"  height="74" width="140" alt="logo" align="absmiddle"/><B style="margin-left:20px;"><font face="calibiri" size="+3" color="#FFFFFF">Fort View ERP</font></B>
	</div>
	<div class="main_common">
		<div class="login_div">
			<div align="right">
				<a href="adminhomepage.php"><img src="http://localhost/shimpiproject/book_images/home.jpg" height="50" width="50" alt="home" title="Home" align="absmiddle"></a>&nbsp;&nbsp;&nbsp;&nbsp;||&nbsp;&nbsp;&nbsp;&nbsp;<a href="addauthor.php?uploadOk=0&msgerr=&author="><img src="http://localhost/shimpiproject/book_images/bk.png" height="50" width="70" alt="back" title="Go Back One Page" align="absmiddle"></a>&nbsp;&nbsp;&nbsp;&nbsp;||&nbsp;&nbsp;&nbsp;&nbsp;<B><font face="Times New Roman" size="4">Welcome:</font>&nbsp;<font face="Times New Roman" size="4" color="#000099"><?php echo $_SESSION["userid"];?><bean:write name="LoginForm" property="id"/></font></B>&nbsp;&nbsp;&nbsp;&nbsp;||&nbsp;&nbsp;&nbsp;&nbsp;<a href="logout.php"><b><font size="3">Logout</font></b></a>&nbsp;&nbsp;&nbsp;&nbsp;		
			</div>
			<div align="center">
				<b><font face="calibiri" size="+2" color="#000099">View Book Author</font></b><br><br><br><br>
				<div align="center">
					<B><font color="#FF0000" size=2.5><?php echo $failMsg;?></font></B>
					<B><font color="#347235" size=2.5><?php echo $succMsg;?></font></B>
					<br><br>
				</div>
				<form name="viewForm" action="view_editAuthor.php" method="post">
					<input type="hidden" name="h1" value="">
					<input type="hidden" name="h2" value="">
					<input type="hidden" name="h3" value="">			
					<table border=0>
					<?php
						$sql1 = "select * from addauthor";
						$result1=mysqli_query($conn,$sql1);

						if(mysqli_num_rows($result1)<0){
					?>
						<tr>
							<td align="center" valign="middle" colspan=4>
								<b><font size="3" face="Times New Roman">No Book author records are available.</font></b><br><br><br><br>
							</td>
						</tr>
					<?php		
						}
						else{
					?>
							<tr>
								<th align="center" valign="middle">
									<b><font face="Times New Roman" size="3">Book Author</font></b>
								</th>
							</tr>
					<?php		
							$i=1;
							while($row= mysqli_fetch_array($result1)){
								$id = $row['id'];
								$author = $row['authorname'];
								$fname = $row['filename'];
					?>
								<tr>
									<td align="center" valign="middle">
										<input type="hidden" name="hideAuthor<?php echo $i; ?>" value="<?php echo $author;?>">
										<input type="hidden" name="hideFilename<?php echo $i; ?>" value="<?php echo $author;?>">
										<input type="text" name="hc<?php echo $i; ?>" value="<?php echo $author;?>" size="20" maxlength="20" >
										<input type="text" name="fn<?php echo $i; ?>" value="<?php echo $fname;?>" size="20" maxlength="20" disabled ><br><br>	
									</td>
									<td align="center" valign="middle">
										&nbsp;<input type="submit" name="upload<?php echo $i; ?>" value="Upload" onclick="uploadFile(document.viewForm.hideAuthor<?php echo $i; ?>, document.viewForm.hideFilename<?php echo $i; ?>,'<?php echo $id; ?>');"><br><br>
									</td>	
									<td align="center" valign="middle">
										&nbsp;<input type="submit" name="done<?php echo $i; ?>" value="Done" onclick="changesDone(document.viewForm.hc<?php echo $i; ?>, document.viewForm.fn<?php echo $i; ?>,'<?php echo $id; ?>');"><br><br>
									</td>
									<td align="center" valign="middle">
										&nbsp;<input type="submit" value="Delete" onclick="return delete_author('<?php echo $id; ?>');"><br><br>
									</td>
								</tr>
					<?php		
								$i++;	
							}
						}
					?>
						
					</table>
				</form><br><br>
			</div>
		</div>
	</div>
	<div class="footer">
		<div class="footerLogo1">
			Developed by
		</div>
		<div class="footerLogo2">
			<img src="http://localhost/shimpiproject/book_images/Logo.png">		
		</div>
	</div>
</div>		
</body>
</html>
<?php
mysqli_close($conn);
?>