<?php
session_start();
if(!isset($_SESSION["userid"])){ //If session not registered
	header("location:login.php"); // Redirect to login.php page
}
else
{
	$now=time();
	if($now > $_SESSION['expire'])
	{
		session_destroy();
		header("Location:login.php");
	}
}
include("connectioncode.php");
 ?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title>Book Stock</title>
	<link rel="stylesheet" type="text/css" href="css/style.css"/>
	<style>
.btn
		{
			text-decoration: none;
			border: none;
 			outline: 0;
  			padding: 6px;
  			color: white;
 			background-color: #000;
 			text-align: center;
 			cursor: pointer;
 			font-size: 14px;
 			
		}
		.success{
			color: green;
		}
		.error{
			color:red;
		}
	</style>
</head>
<body>
<?php	
	$msgerr=$sql=$result=$bno="";
	if($msgerr==null){
		$msgerr="";
	}
	$sql1="select * from addcategory";
	$sql2="select * from addauthor";
	$sql3="select * from addpublisher";
	$result1=mysqli_query($conn,$sql1);
	$result2=mysqli_query($conn,$sql2);
	$result3=mysqli_query($conn,$sql3);	

	if ($_SERVER["REQUEST_METHOD"]=="POST")
		{
			$menu1=$_POST["menu1"];
			$menu2=$_POST["menu2"];
			$menu3=$_POST["menu3"];
			$menu4=$_POST["menu4"];

			if ($menu1=="0" && $menu2=="0" && $menu3=="0" && $menu4=="0") 
			{
				$msgerr = "Please Select any one of the option.";
				$sql="";
				$result="";
				$bno="";
				//header("Location:bookstock.php?msgerr=$msgerr");
			}
			else if($menu1!="0" && $menu2=="0" && $menu3=="0" && $menu4=="0"){
				$sql = "select * from addbook where categoryid=\"$menu1\"";	
				$result=mysqli_query($conn,$sql);	
				$bno = mysqli_num_rows($result);							
			}
			else if($menu1=="0" && $menu2!="0" && $menu3=="0" && $menu4=="0"){
				$sql = "select * from addbook where authorid=\"$menu2\"";	
				$result=mysqli_query($conn,$sql);	
				$bno = mysqli_num_rows($result);
			}
			else if($menu1=="0" && $menu2=="0" && $menu3!="0" && $menu4=="0"){
				$sql = "select * from addbook where publisherid=\"$menu3\"";	
				$result=mysqli_query($conn,$sql);	
				$bno = mysqli_num_rows($result);
			}	
			else if($menu1=="0" && $menu2=="0" && $menu3=="0" && $menu4!="0"){
				$sql = "select * from addbook where language=\"$menu4\"";	
				$result=mysqli_query($conn,$sql);	
				$bno = mysqli_num_rows($result);
			}
			else if($menu1!="0" && $menu2!="0" && $menu3=="0" && $menu4=="0"){
				$sql = "select * from addbook where categoryid=\"$menu1\" and authorid=\"$menu2\"";	
				$result=mysqli_query($conn,$sql);	
				$bno = mysqli_num_rows($result);	
			}
			else if($menu1!="0" && $menu2=="0" && $menu3!="0" && $menu4=="0"){
				$sql = "select * from addbook where categoryid=\"$menu1\" and publisherid=\"$menu3\"";	
				$result=mysqli_query($conn,$sql);	
				$bno = mysqli_num_rows($result);
			}
			else if($menu1!="0" && $menu2=="0" && $menu3=="0" && $menu4!="0"){
				$sql = "select * from addbook where categoryid=\"$menu1\" and language=\"$menu4\"";	
				$result=mysqli_query($conn,$sql);	
				$bno = mysqli_num_rows($result);
			}
			else if($menu1=="0" && $menu2!="0" && $menu3!="0" && $menu4=="0"){
				$sql = "select * from addbook where authorid=\"$menu2\" and publisherid=\"$menu3\"";	
				$result=mysqli_query($conn,$sql);	
				$bno = mysqli_num_rows($result);
			}
			else if($menu1=="0" && $menu2!="0" && $menu3=="0" && $menu4!="0"){
				$sql = "select * from addbook where authorid=\"$menu2\" and language=\"$menu4\"";	
				$result=mysqli_query($conn,$sql);	
				$bno = mysqli_num_rows($result);
			}
			else if($menu1=="0" && $menu2=="0" && $menu3!="0" && $menu4!="0"){
				$sql = "select * from addbook where publisherid=\"$menu3\" and language=\"$menu4\"";	
				$result=mysqli_query($conn,$sql);	
				$bno = mysqli_num_rows($result);
			}
			else if($menu1!="0" && $menu2!="0" && $menu3!="0" && $menu4=="0"){
				$sql = "select * from addbook where categoryid=\"$menu1\" and authorid=\"$menu2\" and publisherid=\"$menu3\"";	
				$result=mysqli_query($conn,$sql);	
				$bno = mysqli_num_rows($result);
			}
			else if($menu1=="0" && $menu2!="0" && $menu3!="0" && $menu4!="0"){
				$sql = "select * from addbook where authorid=\"$menu2\" and publisherid=\"$menu3\" and language=\"$menu4\"";	
				$result=mysqli_query($conn,$sql);	
				$bno = mysqli_num_rows($result);
			}
			else if($menu1!="0" && $menu2!="0" && $menu3=="0" && $menu4!="0"){
				$sql = "select * from addbook where categoryid=\"$menu1\" and authorid=\"$menu2\" and language=\"$menu4\"";	
				$result=mysqli_query($conn,$sql);	
				$bno = mysqli_num_rows($result);
			}
			else if($menu1!="0" && $menu2!="0" && $menu3!="0" && $menu4!="0"){
				$sql = "select * from addbook where categoryid=\"$menu1\" and authorid=\"$menu2\" and publisherid=\"$menu3\" and language=\"$menu4\"";	
				$result=mysqli_query($conn,$sql);	
				$bno = mysqli_num_rows($result);
			}			
		}
?>	

<div class="main_contain">
	<div class="header" style="background-color: purple">
		<img src="http://localhost/shimpiproject/book_images/Logo.png"  height="74" width="140" alt="logo" align="absmiddle"/><B style="margin-left:20px;"><font face="calibiri" size="+3" color="#FFFFFF">Admin Home Page</font></B>
	</div>
	<div class="main_addCategory">
		<div class="login_div">
			<div align="right">				
				<a href="adminhomepage.php"><img src="http://localhost/shimpiproject/book_images/home.jpg" height="50" width="50" alt="home" title="Home" align="absmiddle"></a>&nbsp;&nbsp;&nbsp;&nbsp;||&nbsp;&nbsp;&nbsp;&nbsp;<a href="adminhomepage.php"><img src="http://localhost/shimpiproject/book_images/bk.png" height="50" width="70" alt="back" title="Go Back One Page" align="absmiddle"></a>&nbsp;&nbsp;&nbsp;&nbsp;||&nbsp;&nbsp;&nbsp;&nbsp;<B><font face="Times New Roman" size="4">Welcome:</font></B><font face="Times New Roman" size="4" color="#000099"><?php echo $_SESSION["userid"];?></font>&nbsp;&nbsp;&nbsp;&nbsp;||&nbsp;&nbsp;&nbsp;&nbsp;<a href="logout.php"><b><font size="3">Logout</font></b></a>&nbsp;&nbsp;&nbsp;&nbsp;								
			</div>
			<div align="center">
				<b><font face="calibiri" size="+2" color="#000099">Book Stock</b></font></b><br><br><br><br>
				<div align="center">
					<B><font color="#FF0000" size=2.5><?php echo $msgerr;?></font></B>					
					<br><br>
				</div>
				<form action="bookstock.php" method="post">
					<table border=0>
						<tr>
							<td >
								<select name="menu1" required>
									<option value="0">Select Category:</option>
									<?php if(mysqli_num_rows($result1)>0){
												while($row= mysqli_fetch_array($result1)){
													if($row['id']==$menu1){
													?>
														<option value="<?php echo $row['id']; ?>" selected><?php echo $row['categoryname']; ?></option>														
													<?php
													} 
													else{
													?>

														<option value="<?php echo $row['id']; ?>"><?php echo $row['categoryname']; ?></option>
													<?php
													}														
										 		}
											}
									 ?>		
								</select>
							</td>
							<td>
								<select name="menu2" required>
									<option value="0">Select Author:</option>
									<?php if(mysqli_num_rows($result2)>0){
												while($row= mysqli_fetch_array($result2)){ 
													if($row['id']==$menu2){
													?>
														<option value="<?php echo $row['id']; ?>" selected><?php echo $row['authorname']; ?></option>
													<?php														
													}	
													else{
													?>																						
														<option value="<?php echo $row['id']; ?>"><?php echo $row['authorname']; ?></option>
													<?php				
													}
										 		}
											}
									 ?>		
								</select>
							</td>
							<td>
								<select name="menu3" required>
									<option value="0">Select Publisher:</option>
									<?php if(mysqli_num_rows($result3)>0){
												while($row= mysqli_fetch_array($result3)){	
													if($row['id']==$menu3){
													?>
														<option value="<?php echo $row['id']; ?>" selected><?php echo $row['publishername']; ?></option>
													<?php	
													}
													else{
													?>														
														<option value="<?php echo $row['id']; ?>"><?php echo $row['publishername']; ?></option>
													<?php					
													}
										 		}
											}
									 ?>		
								</select>
							</td>
							<td>
								<select name="menu4" required>									
									<?php
									if($menu4=="0"){
									?>
										<option value="0" selected>Select Language:</option>
									<?php	
									}
									else{
									?>
										<option value="0">Select Language:</option>
									<?php
									}

									if ($menu4=="hindi") {
									?>
										<option value="hindi" selected>Hindi</option>										
									<?php	# code...
									}
									else{
									?>
										<option value="hindi">Hindi</option>
									<?php	
									}

									if ($menu4=="english") {
									?>
										<option value="english" selected>English</option>										
									<?php	# code...
									}
									else{
									?>
										<option value="english">English</option>
									<?php	
									}
									
									if ($menu4=="marathi") {
									?>
										<option value="marathi" selected>Marathi</option>										
									<?php	# code...
									}
									else{
									?>
										<option value="marathi">Marathi</option>
									<?php	
									}
									
									if ($menu4=="gujrati") {
									?>
										<option value="gujrati" selected>Gujrati</option>										
									<?php	# code...
									}
									else{
									?>
										<option value="gujrati">Gujrati</option>
									<?php	
									}
									
									if ($menu4=="telugu") {
									?>
										<option value="telugu" selected>Telugu</option>										
									<?php	# code...
									}
									else{
									?>
										<option value="telugu">Telugu</option>
									<?php	
									}
									
									if ($menu4=="tamil") {
									?>
										<option value="tamil" selected>Tamil</option>										
									<?php	# code...
									}
									else{
									?>
										<option value="tamil">Tamil</option>
									<?php	
									}
									
									if ($menu4=="malyalam") {
									?>
										<option value="malyalam" selected>Malyalam</option>										
									<?php	# code...
									}
									else{
									?>
										<option value="malyalam">Malyalam</option>
									<?php	
									}
									?>
								</select>
							</td>
							<td>&nbsp;</td>
							<td align="left" valign="middle" colspan="2">
								<input type="submit" value="Submit" class="btn">
							</td>
						</tr>
						</table><br><br><br><br>

				<?php
				if($bno!=""){
				?>
					<table border="1">
						<tr>
							<td colspan="6" align="left"><B><font face="Times New Roman" size="5" color="blue">Number of Books:<?php echo $bno;?></font></B></td>			
						</tr>	
						<tr>
							<th>
								<font face="Times New Roman" size="3">Category Name</font>
							</th>
							<th>
								<font face="Times New Roman" size="3">Author Name</font>
							</th>
							<th>
								<font face="Times New Roman" size="3">Publisher Name</font>
							</th>
							<th>
								<font face="Times New Roman" size="3">Language</font>
							</th>
							<th>
								<font face="Times New Roman" size="3">Book Name</font>
							</th>
							<th>
								<font face="Times New Roman" size="3">Book Number</font>								
							</th>
						</tr>
						<?php 
						$cname=$aname=$pname="";
						if(mysqli_num_rows($result)>0){
							while($row= mysqli_fetch_array($result)){
								$cid = $row['categoryid'];
									$sql4 = "select categoryname from addcategory where id=\"$cid\"";
									$res1 = mysqli_query($conn,$sql4);
									if(mysqli_num_rows($res1)>0){
										while($row2= mysqli_fetch_array($res1)){
											$cname = $row2['categoryname'];
										}	
									}
									else{
										$cname="";
									}
								$aid = $row['authorid'];
									$sql5 = "select authorname from addauthor where id=\"$aid\"";
									$res2 = mysqli_query($conn,$sql5);
									if(mysqli_num_rows($res2)>0){
										while($row2= mysqli_fetch_array($res2)){
											$aname = $row2['authorname'];
										}	
									}
									else{
										$aname="";
									}
								$pid = $row['publisherid'];
									$sql6 = "select publishername from addpublisher where id=\"$pid\"";
									$res3 = mysqli_query($conn,$sql6);
									if(mysqli_num_rows($res3)>0){
										while($row2= mysqli_fetch_array($res3)){
											$pname = $row2['publishername'];
										}	
									}
									else{
										$pname="";
									}
								$lang = $row['language'];
								$bkname = $row['bookname'];
								$bkno = $row['bookno'];
								$bkprice= $row['bookprice'];
							?>
								<tr>
									<td>
										<font face="Times New Roman" size="3"><?php echo $cname;?></font>
									</td>
									<td>
										<font face="Times New Roman" size="3"><?php echo $aname;?></font>
									</td>
									<td>
										<font face="Times New Roman" size="3"><?php echo $pname;?></font>
									</td>
									<td>
										<font face="Times New Roman" size="3"><?php echo $lang;?></font>
									</td>
									<td>
										<font face="Times New Roman" size="3"><?php echo $bkname;?></font>
									</td>
									<td>
										<font face="Times New Roman" size="3"><?php echo $bkno;?></font>
									</td>
									<td>
										<font face="Times New Roman" size="3"><?php echo $bkprice;?></font>
									</td>	
								</tr>	
							<?php	
							}	
						}
						else{
						?>
							<tr>
								<td colspan="6"><b><font face="Times New Roman" size="3">No Records Available.</font></b></td>
							</tr>	
						<?php	
						}	
						?>	
					</table><br><br><br>
				<?php	
				}
				else{
				?>
					<table>
						<tr>
							<td>
								<b><font face="Times New Roman" size="3">No Records Available.</font></b>
							</td>	
						</tr>	
					</table>	
				<?php	
				}
				mysqli_close($conn);
				?>	
				</form><br><br><br><br>								
			</div>
		</div>
	</div>
	<br><br><br><br><br>
	<br><br>
	
	<div class="footer">
		<div class="footerLogo1">
			Developed by
		</div>
		<div class="footerLogo2">
			<img src="http://localhost/shimpiproject/book_images/Logo.png">		
		</div>
	</div>
</body>
</html>