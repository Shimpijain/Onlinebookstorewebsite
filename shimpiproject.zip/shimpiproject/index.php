<?php
session_start();

include("connectioncode.php");
?>
<!DOCTYPE html>
<html>
<head>
	<title> SHRAVI ONLINE BOOK STORE.in</title>
	<meta name="viewport"
	content="width=device-width,initial-scale=1">
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  	<script type="text/javascript" src="screenRes.js"></script>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

	<style>
		
		.head
		{
			padding-top: 10px;
		}
		.logo
		{
			padding-left: 1250px;
			padding-top: -100px;
		}
		.search
		{
			margin:-100px;
		padding-left:1000px;
		height: 90px;

		}
		.search input
		{
			height: 30px;
		}
		.image
		{
     		display: inline;
     		padding: 10px;
     		cursor: pointer;
 		}
 		.author
 		{
 			cursor: pointer;
 		}
 		.publisher
 		{
 			cursor: pointer;
 		}
 		.language
 		{
 			cursor: pointer;
 		}
 		.leftside
 		{
 			float: left;
 			border: none;
 		}
 		.rightside
 		{
 			float: right;
 		}
 		#myBtn 
		{
		  display: none;
		  position: fixed;
		  bottom: 20px;
		  right: 30px;
		  z-index: 99;
		  font-size: 18px;
		  border: none;
		  outline: none;
		  background-color: black;
		  color: white;
		  cursor: pointer;
		  padding: 15px;
		  border-radius: 4px;
		}
		#myBtn:hover {
		  background-color: #555;
		}
		* {
			  box-sizing: border-box;
			}

			form.example input[type=text] {
			  padding: 10px;
			  font-size: 17px;
			  border: 1px solid grey;
			  float: right;
			  width: 80%;
			  background: #f1f1f1;
			}

			form.example button {
			  float: right;
			  width: 20%;
			  padding: 10px;
			  background: #2196F3;
			  color: white;
			  font-size: 17px;
			  border: 1px solid grey;
			  border-left: none;
			  cursor: pointer;
			}

			form.example button:hover {
			  background: #0b7dda;
			}

			form.example::after {
			  content: "";
			  clear: both;
			  display: table;
			}
	</style>
</head>
<body>
	<button onclick="topFunction()" id="myBtn" title="Go to top">Top</button>
	<div><?php include("menubar.php"); ?></div>
	<?php include("header.html"); ?>
	<marquee><font face="arabic typesetting" size="5"><b> WELCOME TO SHRAVI ONLINE BOOK STORE HAVE A GOOD CHOICE</b></font></marquee>
	
  	<br>
  	<br>
  	<div style="background-color: lightblue;height: 60px;">

		<form class="example" action="books.php?cid=&aid=&pid=&lang=&msg=&srch=" style="margin:auto;max-width:500px;" method="POST">
	  		<input type="hidden" name="email" value="">
	  		<input type="hidden" name="comment" value="">
  			<input type="text" placeholder="Enter book name..." name="search">
  			<button type="submit" name="submit"><i class="fa fa-search"></i></button>
		</form>
	</div>
  	<br><br>
  	<div style="background-color: lightgrey; width: 1340px; height: 2px ;float: left;" ></div>
	<br>
	<br>
	<h2> Shop By Gerne</h2>
	 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

	 	<?php
			$sql ="select * from addcategory";
			$result= mysqli_query($conn, $sql);
			if(mysqli_num_rows($result)>0){
				while($row=mysqli_fetch_array($result))
					{
						$filename=$row['filename'];
						$id=$row['id'];
		?>	
						<a href="books.php?cid=<?php echo $id; ?>&aid=&pid=&lang=&msg="><img src="http://localhost/shimpiproject/book_images/category/<?php echo $filename; ?>"></a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

				<?php
					}
			}		
		?>		
  	<br>
  	 <div style="background-color: lightgrey; width: 1350px; height: 2px ;float: left;" ></div>
  	 <br>
  	<div>
  		<div class="leftside" style="height:900px;width:260px;background-color: transparent;">
  			<br>
			<label style="color: grey; font-size: 20px"> Show Results For-</label><br>
			<table>
					<tr>
						<?php
					$sql ="select * from addcategory";
					$result= mysqli_query($conn, $sql);
					if(mysqli_num_rows($result)>0){
					while($row=mysqli_fetch_array($result))
					{
						$categoryname=$row['categoryname'];
						$id=$row['id'];
					?>	
						<a href="books.php?cid=<?php echo $id; ?>&aid=&pid=&lang=&msg=" style="margin-left:50px;font-size: 25px;color: red;cursor: pointer;"><?php echo $categoryname ?></a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br>

				<?php
					}
			}		
		?>
					</tr>
			</table>
		</div>
		<center>
			<h1>
				<font size="52" color="red" face="Brush Script MT">
				Featured & Series Authors
				</font>
 			</h1>
		</center>
					<?php
						$sql ="select * from addauthor where id between 1 and 7";
						$result= mysqli_query($conn, $sql);
						if(mysqli_num_rows($result)>0){
							while($row=mysqli_fetch_array($result))
								{
									$filename=$row['filename'];
									$id=$row['id'];
					?>	
						<a href="books.php?cid=&aid=<?php echo $id; ?>&pid=&lang=&msg="><img class="author" src="http://localhost/shimpiproject/book_images/author/<?php echo $filename; ?>" width="200"></a>
						&nbsp;

						<?php
					}
				}		
			?>
			<a href="authomenu.php" style="margin-left:1000px;">More>></a>
			<br><br>
					
					
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<div style="background-color: lightgrey; width: 1000px; height: 2px ;float: right;" ></div>
			<br><br><br>
			<center>
			<h1>
				<font size="52" color="red" face="Brush Script MT">
				Featured Publishers</font>
			</h1>
		</center>

								<?php
						$sql ="select * from addpublisher  where id between 0 and 6";
						$result= mysqli_query($conn, $sql);
						if(mysqli_num_rows($result)>0){
							while($row=mysqli_fetch_array($result))
								{
									$filename=$row['filename'];
									$id=$row['id'];
					?>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="books.php?cid=&aid=&pid=<?php echo $id; ?>&lang=&msg="><img class="publisher" src="http://localhost/shimpiproject/book_images/publisher/<?php echo $filename; ?>" width="150"></a>
						<?php
					}
				}

			?>	
						<a href="publishermenu.php" style="margin-left:1000px;">More>></a>
			
			<br><br>	

					&nbsp;
		<br>
		<br>
		<div style="background-color: lightgrey; width: 1000px; height: 2px ;float: right;" ></div>
		<center>
			<h1>
				<font size="52" color="black" face="arial">
				Books In Indian Languages
			<div style="background-color: lightgrey; width: 1000px; height: 2px ;float: right;" ></div>

			</h1>
		</center>
		<a href="books.php?cid=&aid=&pid=&lang=hindi&msg="><img class="language" src="http://localhost/shimpiproject/book_images/languages1.jpg" width="250"></a>

		<a href="books.php?cid=&aid=&pid=&lang=english&msg="><img class="language" src="http://localhost/shimpiproject/book_images/english.jpg" width="250"></a>

		<a href="books.php?cid=&aid=&pid=&lang=marathi&msg="><img class="language" src="http://localhost/shimpiproject/book_images/languages2.jpg" width="250"></a>

		<a href="books.php?cid=&aid=&pid=&lang=tamil&msg="><img class="language" src="http://localhost/shimpiproject/book_images/languages3.jpg" width="250"></a>

		<a href="books.php?cid=&aid=&pid=&lang=telugu&msg="><img class="language" src="http://localhost/shimpiproject/book_images/languages4.jpg" width="250"></a>

		<a href="books.php?cid=&aid=&pid=&lang=malayalam&msg="><img class="language" src="http://localhost/shimpiproject/book_images/languages5.jpg" width="250"></a>

		<a href="books.php?cid=&aid=&pid=&lang=gujarati&msg="><img class="language" src="http://localhost/shimpiproject/book_images/languages6.jpg" width="250"></a>
		<div style="background-color: lightgrey; width: 1000px; height: 2px ;float: right;" ></div>
  	</div>		
  	</div>
  	<div><marquee><font style="font-size: 20px;" face="chiller">Thanks, for visit my website</font></marquee></div>
  	<div style="line-height: 10px">
  		<font style="font-size: 20px;color: #e68a00; margin-left: 300px">Explore and Buy Books at Shravi India</font><br>
  		<font style="font-size: 15px;color: black;margin-left: 300px">Amazon.in offers you over 10 million titles across categories such as Children’s Books, Business & Economics, Indian Writing and Literature & Fiction.<br>
  		<font style="font-size: 15px;color: black;margin-left: 300px">Reading books is the favourite pastime of many people. If you’re bitten by the book-bug too, then there is a massive collection of books for you to read.</font><br><font style="font-size: 15px;color: black;margin-left: 300px"> From bestsellers to new & future releases, the choices are exhaustive when you shop online at India's Largest Bookstore.</font>
  	</div>
  	<?php include("foter.php"); ?>
	<script>
		var mybutton = document.getElementById("myBtn");
		window.onscroll = function() {scrollFunction()};
		function scrollFunction() {
		  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
		    mybutton.style.display = "block";
		  } else {
		    mybutton.style.display = "none";
		  }
		}
		function topFunction() {
		  document.body.scrollTop = 0;
		  document.documentElement.scrollTop = 0;
		}
	</script>
</body>    
</html>
<?php
mysqli_close($conn);
?>