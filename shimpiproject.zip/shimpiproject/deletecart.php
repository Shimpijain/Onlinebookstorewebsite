<?php 
include("connectioncode.php");
if(isset($_SESSION["loggedmail"]))
			{
				$mailid = $_SESSION["loggedmail"];
			}
$dsql = "delete from addtocart where id=\"$id\"";
if(mysqli_query($conn,$dsql)){
	header("Location:addtocartbook.php");
	}	
?>