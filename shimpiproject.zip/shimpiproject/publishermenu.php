<?php
	include("connectioncode.php");
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<div><?php include("menubar.php"); ?></div>
<center><a href="index.php" ><img src="http://localhost/shimpiproject/book_images/Logo.png" height="60" width="100"></a></center>
<div>
	<center>
		<font style="font-size: 35px;color:red">
			Featured & Series Authors
		</font>
	</center><br><br>
	<?php
			$sql ="select * from addpublisher";
			$result= mysqli_query($conn, $sql);
			if(mysqli_num_rows($result)>0){
				while($row=mysqli_fetch_array($result))
					{
						$filename=$row['filename'];
						$id=$row['id'];
		?>	
						<a href="books.php?cid=&aid=&pid=<?php echo $id; ?>&lang=&msg="><img src="http://localhost/shimpiproject/book_images/publisher/<?php echo $filename; ?>"width="200" height="120" style="margin-left: 20px"></a>

				<?php
						}
					}		
				?>		
</div>
<div><?php include("foter.php"); ?></div>
</body>
</html>
<?php
	mysqli_close($conn);
?>