<?php
include("connectioncode.php");
?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>   
    .sidenav {
      height: 100%;
      width: 0;
      position: fixed;
      z-index: 1;
      top: 0;
      left: 0;
      background-color: #111;
      overflow-x: hidden;
      transition: 0.5s;
      padding-top: 60px;
    }

    .sidenav a {
      padding: 8px 8px 8px 32px;
      text-decoration: none;
      font-size: 15px;
      color: white;
      display: block;
      transition: 0.3s;
    }

    .sidenav a:hover {
      color: white;
    }

    .sidenav .closebtn {
      position: absolute;
      top: 0;
      right: 25px;
      font-size: 36px;
      margin-left: 50px;
    }

    #main {
      transition: margin-left .5s;
      padding: 16px;
    }

    @media screen and (max-height: 450px) {
      .sidenav {padding-top: 15px;}
      .sidenav a {font-size: 18px;}
    }
    .cart
    {
      background-image: url('http://localhost/shimpiproject/book_images/cartlogo.jpg');
      height: 50px;
      width: 80px;
      float: right;
      margin-right:50px;
      color: white; 
      position: relative;
      margin-top: 10px;
      cursor: pointer;
    }
    .plus
    {
      margin-left:40px;
      font-size: 25px; 
      cursor: pointer;
    }
    form.example input[type=text] {
  padding: 10px;
  font-size: 17px;
  border: 1px solid grey;
  float: left;
  width: 80%;
  background: #f1f1f1;
}

form.example button {
  width: 20%;
  padding: 10px;
  background: #2196F3;
  color: white;
  font-size: 17px;
  border: 1px solid grey;
  border-left: none;
  cursor: pointer;
}

form.example button:hover {
  background: #0b7dda;
}

form.example::after {
  content: "";
  clear: both;
  display: table;
}
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}
/* Desktop Styles */
@media only screen and (min-width: 961px) {
  body {
    background-color: white; /* Blue */
  }
}
</style>
</head>
<body>
  <?php
  $emailid="";
  $count=0;
  if(isset($_SESSION["loggedmail"])){
    $emailid = $_SESSION["loggedmail"];
    $sql="select * from addtocart where emailid=\"$emailid\"";
    $result=mysqli_query($conn,$sql); 
    $count = mysqli_num_rows($result);
  }
  else{
    $emailid="";
    $count=0;
  }  
  ?>
  <div style="background-color: black; height: 70px;width: 1349px">
      <div class="cart">
         <?php
          if(isset($_SESSION["loggedmail"])){
        ?>
           <a href="signout.php"><font color="white" style="margin-left: -55px">Sign out</font></a> 
        <?php 
          }
        ?>
        <?php
          if($count==0){
         ?>
            <font class="plus">+</font>
         <?php   
          }
          else{
         ?>
            <a href="addtocartbook.php" style="text-decoration: none;color: white"><font class="plus" style="background-color: red;border-radius: 15px;"><?php echo $count;?></font></a>
         <?php   
          }
        ?>
        
        <font style="margin-left: 70px;color: orange;font-size: 20px;">Cart</font>
    </div>
          
  <div id="mySidenav" class="sidenav" style="color: white; position: fixed;">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;  </a>
  <?php
  if(isset($_SESSION["loggedmail"])){
   ?>
   <font color="white">Hello, <?php echo $_SESSION["loggedname"];?></font> 
 <?php 
  }
  ?>
  <a href="login.php"><center><img src="http://localhost/shimpiproject/book_images/user1.jpg" height="50" width="50"> <font color="white" style="font-size: 15px">Admin</font></center></a>
  <br>
  &nbsp;<font color="grey">Shop By Category</font>
  <?php
          $sql ="select * from addcategory";
          $result= mysqli_query($conn, $sql);
          if(mysqli_num_rows($result)>0){
          while($row=mysqli_fetch_array($result))
          {
            $categoryname=$row['categoryname'];
            $id=$row['id'];
          ?>  
            <a href="books.php?cid=<?php echo $id;?>&aid=&pid=&lang=&msg=&srch=" style="margin-left:10px;font-size: 20px;cursor: pointer;"><?php echo $categoryname ?></a>

        <?php
          }
      }   
    ?><br><br>
  <?php 
  if(isset($_SESSION["loggedmail"])){
   ?>
   <a href="yourorder.php"><font color="white" size="5">Your Order</font></a> 
 <?php 
  }
  ?>
  <?php 
  if(!isset($_SESSION["loggedmail"])){
   ?>
  <a href="newuserlogin.php"><img src="http://localhost/shimpiproject/book_images/user.jpg" height="50" width="50"><font color="white" style="font-size: 15px">&nbsp;SignIn<br></font></a>
  <?php 
  }
  ?>
  <?php 
  if(isset($_SESSION["loggedmail"])){
   ?>
  <?php 
  }
  ?>
</div>
<div id="main">
  <span style="font-size:20px;cursor:pointer; color: white"  onclick="openNav()">&#9776;Menu</span>
</div>
<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
  document.getElementById("main").style.marginLeft = "25px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
  document.getElementById("main").style.marginLeft= "0";

}
</script>
</div>
</body>
</html> 
