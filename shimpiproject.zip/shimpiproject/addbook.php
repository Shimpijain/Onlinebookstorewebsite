<?php
session_start();
if(!isset($_SESSION["userid"])){ //If session not registered
header("location:login.php"); // Redirect to login.php page
}
else
{
	$now=time();
	if($now > $_SESSION['expire'])
	{
		session_destroy();
		header("Location:login.php");
	}
}

include("connectioncode.php");
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Add books</title>
<link rel="stylesheet" type="text/css" href="css/style.css"/>
<style>
.btn
		{
			text-decoration: none;
			border: none;
 			outline: 0;
  			padding: 12px;
  			color: white;
 			background-color: #000;
 			text-align: center;
 			cursor: pointer;
			width: 60%;
 			font-size: 18px;
 			
		}
		.success{
			color: green;
		}
		.error{
			color:red;
		}
	</style>
	<script type="text/javascript">
		function uploadfile(){
			document.frm.action="upload3.php";
			document.frm.submit();
		}

	</script>
</head>
<body>
<?php	
	$msg=$imagename=$errmsg=$menu1=$menu2=$menu3=$menu4=$bookname=$bookno=$bookprice="";
		$uploadOk=$_GET["uploadOk"];
		if($uploadOk==0){
			$errmsg = $_GET["msgerr"];
			$menu1 = $_GET["menu1"];
			$menu2 = $_GET["menu2"];
			$menu3 = $_GET["menu3"];
			$menu4 = $_GET["menu4"];
			$bookname = $_GET["bookname"];
			$bookno = $_GET["bookno"];
			$bookprice= $_GET["bookprice"];
			$imagename="";
		}
		else{
			$msg = $_GET["msg"];			
			$menu1 = $_GET["menu1"];
			$menu2 = $_GET["menu2"];
			$menu3 = $_GET["menu3"];
			$menu4 = $_GET["menu4"];
			$bookname = $_GET["bookname"];
			$bookno = $_GET["bookno"];			
			$imagename = $_GET["imagename"];
			$bookprice= $_GET["bookprice"];
		}
	
	$sql="SELECT id, categoryname FROM addcategory";
	$sql1="SELECT id, authorname FROM addauthor";
	$sql2="SELECT id, publishername FROM addpublisher";
	$result=mysqli_query($conn,$sql);
	$result1=mysqli_query($conn,$sql1);
	$result2=mysqli_query($conn,$sql2);
?>
	<div class="main_contain">
	<div class="header" style="background-color: purple">
		<img src="http://localhost/shimpiproject/book_images/Logo.png"  height="74" width="140" alt="logo" align="absmiddle"/><B style="margin-left:20px;"><font face="calibiri" size="+3" color="#FFFFFF">Admin Home Page</font></B>
	</div>
	<div class="main_addCategory">
		<div class="login_div">
			<div align="right">				
				<a href="adminhomepage.php"><img src="http://localhost/shimpiproject/book_images/home.jpg" height="50" width="50" alt="home" title="Home" align="absmiddle"></a>&nbsp;&nbsp;&nbsp;&nbsp;||&nbsp;&nbsp;&nbsp;&nbsp;<a href="adminhomepage.php"><img src="http://localhost/shimpiproject/book_images/bk.png" height="50" width="70" alt="back" title="Go Back One Page" align="absmiddle"></a>&nbsp;&nbsp;&nbsp;&nbsp;||&nbsp;&nbsp;&nbsp;&nbsp;<B><font face="Times New Roman" size="4">Welcome:</font>&nbsp;<font face="Times New Roman" size="4" color="#000099"><?php echo $_SESSION["userid"];?><bean:write name="LoginForm" property="id"/></font></B>&nbsp;&nbsp;&nbsp;&nbsp;||&nbsp;&nbsp;&nbsp;&nbsp;<a href="view_editBook.php?succMsg=&failMsg="><img src="http://localhost/shimpiproject/book_images/d.png" height="40" width="40" alt="home" align="absmiddle"><b><font size=3>View/Edit/Delete</font></b></a>&nbsp;&nbsp;&nbsp;&nbsp;||&nbsp;&nbsp;&nbsp;&nbsp;<a href="logout.php"><b><font size="3">Logout</font></b></a>&nbsp;&nbsp;&nbsp;&nbsp;								
			</div>
			<div align="center">
				<b><font face="calibiri" size="+2" color="#000099">Add Books</b></font></b><br><br><br><br>
				<p><span class="success"><b><font face="calibiri" size="+1"><?php echo $msg; ?></b></font></span></p>
				<p><span class="error"><b><font face="calibiri" size="+1"><?php echo $errmsg; ?></font></b></span></p>
				<form action="upload3.php" name="frm" method="post" focus="menu" enctype="multipart/form-data">
					<table border=0>
						<tr>
							<td align="right" valign="middle"><font size="3" face="Times New Roman"> Select Category:</font> <br><br></td>
							<td >
								<select name="menu1" required>
									<option value="0">Select Category:</option>
									<?php if(mysqli_num_rows($result)>0){
												while($row= mysqli_fetch_array($result)){ 
													if($row['id']==$menu1){
													?>
														<option value="<?php echo $row['id']; ?>" selected><?php echo $row['categoryname']; ?></option>
													<?php	
													}
													else{
													?>
														<option value="<?php echo $row['id']; ?>"><?php echo $row['categoryname']; ?></option>
													<?php	
													}													
										 		}
											}
									 ?>		
								</select><br><br>
							</td>
						</tr>
						<tr>
							<td align="right" valign="middle"><font size="3" face="Times New Roman"> Select Author:</font> <br><br></td>
							<td >
								<select name="menu2" required>
									<option value="0">Select Author:</option>
									<?php if(mysqli_num_rows($result1)>0){
												while($row= mysqli_fetch_array($result1)){ 
													if($row['id']==$menu2){
													?>
														<option value="<?php echo $row['id']; ?>" selected><?php echo $row['authorname']; ?></option>
													<?php	
													}
													else{
													?>
														<option value="<?php echo $row['id']; ?>"><?php echo $row['authorname']; ?></option>
													<?php	
													}													
										 		}
											}
									 ?>		
								</select><br><br>
							</td>
						</tr>
						<tr>
							<td align="right" valign="middle"><font size="3" face="Times New Roman"> Select Publisher:</font> <br><br></td>
							<td >
								<select name="menu3" required>
									<option value="0">Select Publisher:</option>
									<?php if(mysqli_num_rows($result2)>0){
												while($row= mysqli_fetch_array($result2)){
													if($row['id']==$menu3){
													?>
														<option value="<?php echo $row['id']; ?>" selected><?php echo $row['publishername']; ?></option>
													<?php	
													}
													else{
													?>
														<option value="<?php echo $row['id']; ?>"><?php echo $row['publishername']; ?></option>
													<?php	
													}													
										 		}
											}
									 ?>		
								</select><br><br>
							</td>
						</tr>
						<tr>
							<td align="right" valign="middle"><font size="3" face="Times New Roman"> Select Language:</font> <br><br></td>
							<td >
								<select name="menu4" required>
									<?php
									if($menu4=="0"){
									?>
										<option value="0" selected>Select Language:</option>
									<?php	
									}
									else{
									?>
										<option value="0">Select Language:</option>
									<?php
									}
										if($menu4=="hindi"){
											?>
										<option value="hindi" selected>Hindi</option>										
									<?php	# code...
									}
									else{
									?>
										<option value="hindi">Hindi</option>
									<?php	
									}

									if ($menu4=="english") {
									?>
										<option value="english" selected>English</option>										
									<?php	# code...
									}
									else{
									?>
										<option value="english">English</option>
									<?php	
									}
									
									if ($menu4=="marathi") {
									?>
										<option value="marathi" selected>Marathi</option>										
									<?php	# code...
									}
									else{
									?>
										<option value="marathi">Marathi</option>
									<?php	
									}
									
									if ($menu4=="gujrati") {
									?>
										<option value="gujrati" selected>Gujrati</option>										
									<?php	# code...
									}
									else{
									?>
										<option value="gujrati">Gujrati</option>
									<?php	
									}
									
									if ($menu4=="telugu") {
									?>
										<option value="telugu" selected>Telugu</option>										
									<?php	# code...
									}
									else{
									?>
										<option value="telugu">Telugu</option>
									<?php	
									}
									
									if ($menu4=="tamil") {
									?>
										<option value="tamil" selected>Tamil</option>										
									<?php	# code...
									}
									else{
									?>
										<option value="tamil">Tamil</option>
									<?php	
									}
									
									if ($menu4=="malyalam") {
									?>
										<option value="malyalam" selected>Malyalam</option>										
									<?php	# code...
									}
									else{
									?>
										<option value="malyalam">Malyalam</option>
									<?php	
									}
									?>																						
								</select><br><br>
							</td>
						</tr>
						<tr>
							<td align="right" valign="middle">
								<font size="3" face="Times New Roman">Enter Book Name:</font> <br><br>
							</td>
							<td>
								<input type="text" name="bookname" value="<?php echo $bookname; ?>" required><br><br>
							<td>
						</tr>
						<tr>
							<td align="right" valign="middle">
								<font size="3" face="Times New Roman">Enter Book No:</font> <br><br>
							</td>
							<td>
								<input type="text"  name="bookno" value="<?php echo $bookno; ?>" required><br><br>
							<td>
						</tr>
						<tr>
							<td align="right" valign="middle">
								<font size="3" face="Times New Roman">Enter Book price:</font> <br><br>
							</td>
							<td>
								<input type="text"  name="bookprice" value="<?php echo $bookprice; ?>" required><br><br>
							<td>
						</tr>
						<tr>
							<td align="right" valign="middle">
								<font font size="3" face="Times New Roman">Select Book Images:</font><br><br> 
							</td>
							<td align="left" valign="middle">
								<input type="file" name="image" multiple required><br><br>
							</td>
							<td>
								<input type="submit" value="upload" style="cursor: pointer;"><br><br>
							</td>
							
						</tr>
						<tr>
							<td align="right" valign="middle">
								<font font size="3" face="Times New Roman">Uploaded Book image:</font><br><br>
							</td>							
							<td align="left" valign="middle" colspan=2>
								<input type="text" name="imagename" value="<?php echo $imagename;?>" size="30" disabled/><br><br>
							</td>							
						</tr>
						<tr>
							<td>&nbsp;</td>
							<td align="left" valign="middle" colspan="2">
								<a href="addbookaction.php?menu1=<?php echo $menu1; ?>&menu2=<?php echo $menu2; ?>&menu3=<?php echo $menu3; ?>&menu4=<?php echo $menu4; ?>&bookname=<?php echo $bookname; ?>&bookno=<?php echo $bookno; ?>&bookprice=<?php echo $bookprice; ?>&imagename=<?php echo $imagename;?>&uploadOk=<?php echo $uploadOk;?>" class="btn">Add Book</a>
							</td>
						</tr>	
					</table>
				</form><br><br><br><br>

			</div>
		</div>
	
	<div class="footer">
		<div class="footerLogo1">
			Developed by
		</div>
		<div class="footerLogo2">
			<img src="http://localhost/shimpiproject/book_images/Logo.png">		
		</div>
	</div>
</body>
</html>
<?php 
	mysqli_close($conn);
?>