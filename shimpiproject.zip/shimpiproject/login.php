<?php 
session_start();
include("connectioncode.php");
?>
<!DOCTYPE html>
<html>
<head>
	<style>
		.error
		{
			color: red;
		}
	</style>
	<title>LOGIN PAGE</title>
	<link rel="stylesheet" type="text/css" href="css/l.css">
</head>
<body>
	<?php
		$nameerr=$passerr=$err="";
		$name=$pass="";
		if ($_SERVER["REQUEST_METHOD"]=="POST")
		{
			if (empty($_POST["username"]))
		 	{
				$nameerr="name is required";
			}
			else
			{
				$name=test_input($_POST["username"]);
			}
			
			if (empty($_POST["password"]))
		 	{
				$passerr="password is required";
			}
			else{
			 	$pass=test_input($_POST["password"]);
			}

				

			$flag = 0;
			$sql = "select * from loginadmin where username=\"$name\" and password=\"$pass\"";
			$vals = mysqli_query($conn, $sql);
			$num = mysqli_num_rows($vals);
			//echo $num;
			if(mysqli_num_rows($vals)>0){	
				$_SESSION["userid"]=$name;
				$_SESSION['start']=time();
				//ending a session in 3 minute from the starting time.
				$_SESSION['expire']=$_SESSION['start'] + (10 * 60);				
				header("Location:adminhomepage.php");	
			}
			else{
				$err = "Invalid Username/Password";
			}
			mysqli_close($conn);
		}

		function test_input($data)
		{
			$data=trim($data);
			$data=stripcslashes($data);
			$data=htmlspecialchars($data);
			return $data;
		}
	?>
	<div class="loginbox">
		<img src="http://localhost/shimpiproject/book_images/download.png" class="download">
		<span class="error"><?php echo $err;?></span>
		<h1>Admin Login</h1>
		<form method="post" action="login.php">
			<p>Login Id<span class="error">* <?php echo $nameerr; ?></span></p>
			<input type="text" name="username" placeholder="Enter Admin name">
			<p> Password<span class="error">* <?php echo $passerr; ?></span></p>
			<input type="password" name="password" placeholder="Enter Password">
			<input type="submit" value="Login">
			<br>
		</form>
	</div>
	<br>
	<a href="index.php"><img src="http://localhost/shimpiproject/book_images/home.jpg" width="70" height="60" style="margin-left: 100px"></a>
</body>
</html>