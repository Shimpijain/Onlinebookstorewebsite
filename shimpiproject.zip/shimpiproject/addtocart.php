<?php
	session_start();
	include("connectioncode.php");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Add To Cart</title>

	<style type="text/css">
		.btn
		{
			width: 150px;
			height: 30px;
			background-color: #ff751a;
			cursor: pointer;
		}
		.btn:hover
		{
			background-color: #993d00;
		}
	</style>
</head>
<body>
	
<?php
	$msg=$msgerr="";
	$categid=$authorid=$publisherid=$language=$bookname=$bookno=$bookprice=$imagename=$mailid=$flag="";
	$flag=$_GET["flag"];
	$categid=$_GET['categid'];
	$authorid=$_GET['authorid'];
	$publisherid=$_GET['publisherid'];
	$language=$_GET['language'];
	$bookname=$_GET['bookname'];
	$bookno=$_GET['bookno'];
	$bookprice=$_GET['bookprice'];
	$imagename=$_GET['imagename'];
	$srchData = $_GET["srch"];	
	$mailid = $_SESSION["loggedmail"]; 
	//echo $id;
	//echo $authorid;
	//echo $publisherid;
	//echo $lang;
	//echo $bookname;
	//echo $bookno;
	//echo $bookprice;
	//echo $imagename; 
	$dupsql = "select * from addtocart where emailid =\"$mailid\" and bookno=\"$bookno\"";
		 $dupres = mysqli_query($conn, $dupsql);          
          if(mysqli_num_rows($dupres)>0)
          {
            $msg = "Book is already added in cart.";            
		            if($flag=="category"){
		            	header("Location:books.php?cid=$categid&aid=&pid=&lang=&msg=$msg&srch=");
		            }
		            
		            if($flag=="author"){
		            	header("Location:books.php?cid=&aid=$authorid&pid=&lang=&msg=$msg&srch=");	
		            }

		            if($flag=="publisher"){
		            	header("Location:books.php?cid=&aid=&pid=$publisherid&lang=&msg=$msg&srch=");		
		            }

		            if($flag=="language"){
		            	header("Location:books.php?cid=&aid=&pid=&lang=$language&msg=$msg&srch=");		
		            }

		            if($flag=="srch"){
		            	header("Location:books.php?cid=&aid=&pid=&lang=&msg=$msg&srch=$srchData");		
		            }
          }
          else
          {
		    	$sql="insert into addtocart(emailid,categoryid,authorid,publisherid,language,bookname,bookno,bookprice,imagename) values(\"$mailid\",\"$categid\",\"$authorid\",\"$publisherid\",\"$language\",\"$bookname\",\"$bookno\",\"$bookprice\",\"$imagename\")";
		 		if(mysqli_query($conn,$sql))
		    	{
		            $msg = "Book added in cart successfully";
		            if($flag=="category"){
		            	header("Location:books.php?cid=$categid&aid=&pid=&lang=&msg=$msg&srch=");
		            }
		            
		            if($flag=="author"){
		            	header("Location:books.php?cid=&aid=$authorid&pid=&lang=&msg=$msg&srch=");	
		            }

		            if($flag=="publisher"){
		            	header("Location:books.php?cid=&aid=&pid=$publisherid&lang=&msg=$msg&srch=");		
		            }

		            if($flag=="language"){
		            	header("Location:books.php?cid=&aid=&pid=&lang=$language&msg=$msg&srch=");		
		            }

		            if($flag=="srch"){
		            	header("Location:books.php?cid=&aid=&pid=&lang=&msg=$msg&srch=$srchData");		
		            }            
				}
			}
			
    ?>
    
<?php 
	include("foter.php"); 
?>
<?php
	mysqli_close($conn);
?>
</body>
</html>