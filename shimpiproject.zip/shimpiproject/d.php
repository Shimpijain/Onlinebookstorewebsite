		.dropbtn
		{
			color: blue;
			padding: -300px;
			font-size: 16px;
  			border: none;
		}
		.dropbtn1
		{
			color: blue;
			padding: -300px;
			font-size: 16px;
  			border: none;
		}
		.dropbtn2
		{
			color: blue;
			padding: -300px;
			font-size: 16px;
  			border: none;
		}
		.dropdown 
		{
  			position: relative;
  			display: inline-block;
  			float: right;
  			width: 250px;
  			word-spacing: normal;

		}
		.dropdown-content 
		{
			 display: none;
			 position: absolute;
			 background-color: none;
			 min-width: 160px;
			 box-shadow: 0px 4px 6px 0px rgba(0,0,0,0.2);
			 z-index: 1;
		}

		.dropdown-content a
		 {
		  	color: black;
  			padding: 12px 16px;
  			text-decoration: none;
  			display: block;
		}.dropdown-content a:hover {background-color: #ddd;}

	.dropdown:hover .dropdown-content {display: block;}

	.dropdown:hover .dropbtn {background-color:none;}