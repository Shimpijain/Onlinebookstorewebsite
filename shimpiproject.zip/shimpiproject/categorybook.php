<?php
	session_start();
	include("connectioncode.php");
?>
<!DOCTYPE html>
<html>
<head>
	<style type="text/css">
		.btn
		{
			width: 150px;
			height: 30px;
			background-color: #ff751a;
			cursor: pointer;
		}
		.btn:hover
		{
			background-color: #993d00;
		}
	</style>
</head>
<body>
	<?php include("menubar.php"); ?><br>
<?php
	$id=$_GET['id'];
	//echo $id;
	$sql="select * from addbook where categoryid=\"$id\"";
	$result=mysqli_query($conn,$sql);

	if(mysqli_num_rows($result)>0)
	{
		while($row= mysqli_fetch_array($result))
		{
			{	$aid = $row['authorid'];
				$sql5 = "select authorname from addauthor where id=\"$aid\"";
				$res2 = mysqli_query($conn,$sql5);
				if(mysqli_num_rows($res2)>0)
				{
					while($row2= mysqli_fetch_array($res2))
					{
						$aname = $row2['authorname'];
					}	
				}
				else
				{
					$aname="";
				}
				$pid = $row['publisherid'];
				$sql6 = "select publishername from addpublisher where id=\"$pid\"";
				$res3 = mysqli_query($conn,$sql6);
				if(mysqli_num_rows($res3)>0)
				{
					while($row2= mysqli_fetch_array($res3))
					{
						$pname = $row2['publishername'];
					}	
				}
				else{
					$pname="";
				}
				$lang = $row['language'];
				$bkname = $row['bookname'];
				$bkno = $row['bookno'];
				$bkprice = $row['bookprice'];
				$bkimage = $row['imagename'];
				?>
				<img src="http://localhost/shimpiproject/book_images/<?php echo $bkimage; ?>" width="300" height="300">
				<div style="margin-left: 300px; margin-top: -300px">
				<label>Author Name:</label>
				<?php
				echo $aname;
				?>
				<br>
				<label>Publisher Name:</label>
				<?php
				echo $pname;
				?>
				<br>
				<label>Language:</label>
				<?php
				echo $lang;
				?>
				<br>
				<label>Book Name:</label>
				<?php
				echo $bkname;
				?>
				<br>
				<label>Book Number:</label>
				<?php
				echo $bkno;
				?>
				<br>
				<label>Book Price:</label>
				<?php
				echo $bkprice;
				?>&#8377;
				<br><br>

				<?php
				if(!isset($_SESSION["loggedmail"])){
				?>
				<a href="newuserlogin.php" class="btn" style="margin-left: 150px">Buy Now</a>
				
				<a href="newuserlogin.php">Add To Cart</a>	
				<?php	
				}
				else{
				?>
				<a href="orderplace.php?id=<?php echo $id; ?>&authorid=<?php echo $aid; ?>&publisherid=<?php echo $pid; ?>&language=<?php echo $lang; ?>&bookname=<?php echo $bkname; ?>&bookprice=<?php echo $bkprice; ?>&bookno=<?php echo $bkno; ?>&imagename=<?php echo $bkimage; ?>" class="btn" style="margin-left: 150px">Buy Now</a>
				
				<a href="addtocart.php?id=<?php echo $id; ?>&authorid=<?php echo $aid; ?>&publisherid=<?php echo $pid; ?>&language=<?php echo $lang; ?>&bookname=<?php echo $bkname; ?>&bookprice=<?php echo $bkprice; ?>&bookno=<?php echo $bkno; ?>&imagename=<?php echo $bkimage; ?>" class="btn" style="margin-left: 150px">Add To Cart</a>
				<?php	
				}
				?>
				<br><br><br><br><br><br>
				<br><br><br><br><br><br>
				</div>
				<?php
			}
			?>

			<div style="height: 1px;width: 100%;background-color: grey"></div><br>
			<?php
		}
	}
?>
<?php include("foter.php"); ?>
</body>
</html>
<?php
mysqli_close($conn);
?>