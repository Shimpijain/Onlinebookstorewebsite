<?php
	function filtername($field)
  	{
    $field=filter_var(trim($field),FILTER_SANITIZE_STRING);
    if(filter_var($field,FILTER_VALIDATE_REGEXP,array("options"=>array("regexp"=>"/^[a-zA-Z\s]+$/"))))
    {
      return $field;
    }
    else
    {
      return FALSE;
    }
  }

  function test_input($data)
    {
      $data=trim($data);
      $data=stripcslashes($data);
      $data=htmlspecialchars($data);
      return $data;
    }

	$menu1 = $_POST["menu1"];
	$menu2 = $_POST["menu2"];
	$menu3 = $_POST["menu3"];
	$menu4 = $_POST["menu4"];
	$bookname=filterName(test_input($_POST["bookname"]));
    $bookno = test_input($_POST["bookno"]);
    $bookprice = test_input($_POST["bookprice"]);
	$imagename = $_POST["imagename"];
	
	if($menu1=="0"){
		$msgerr = "Please fill the required field (*)";
		header("Location:addbook.php?msgerr=$msgerr&uploadOk=0&menu1=$menu1&menu2=$menu2&menu3=$menu3&menu4=$menu4&bookname=$bookname&bookno=$bookno&bookprice=$bookprice");
	}
	else if($menu2=="0"){
		$msgerr = "Please fill the required field (*)";
		header("Location:addbook.php?msgerr=$msgerr&uploadOk=0&menu1=$menu1&menu2=$menu2&menu3=$menu3&menu4=$menu4&bookname=$bookname&bookno=$bookno&bookprice=$bookprice");
	}
	else if($menu3=="0"){
		$msgerr = "Please fill the required field (*)";
		header("Location:addbook.php?msgerr=$msgerr&uploadOk=0&menu1=$menu1&menu2=$menu2&menu3=$menu3&menu4=$menu4&bookname=$bookname&bookno=$bookno&bookprice=$bookprice");
	}
	else if($menu4=="0"){
		$msgerr = "Please fill the required field (*)";
		header("Location:addbook.php?msgerr=$msgerr&uploadOk=0&menu1=$menu1&menu2=$menu2&menu3=$menu3&menu4=$menu4&bookname=$bookname&bookno=$bookno&bookprice=$bookprice");
	}
	else if ($bookname==FALSE) 
    {
       $msgerr= "Please enter the correct value";
       header("Location:addbook.php?msgerr=$msgerr&uploadOk=0&menu1=$menu1&menu2=$menu2&menu3=$menu3&menu4=$menu4&bookname=$bookname&bookno=$bookno&bookprice=$bookprice");
    }   
    else{
	$target_path="book_images/";
	$target_file=$target_path.basename($_FILES["image"]["name"]);
	$uploadOk=1;
	$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
	if(isset($_POST["submit"])){
		$check = getimagesize($_FILES["image"]["tmp_name"]);
		if($check!==false){
			echo "File is an image - ".$check["mime"].".";
			$uploadOk=1;
		}
		else{
			echo "File is not an image.";
			$uploadOk=0;
		}
	}

	if ($imageFileType!="jpg" && $imageFileType!="png" && $imageFileType!= "jpeg")
	{
		$uploadOk=0;
	}

	if($uploadOk==0)
	{
		$msgerr = "Sorry, only JPG,JPEG,PNG files are allowed";
		header("Location:addbook.php?msgerr=$msgerr&uploadOk=$uploadOk&menu1=$menu1&menu2=$menu2&menu3=$menu3&menu4=$menu4&bookname=$bookname&bookno=$bookno&bookprice=$bookprice");
	}
	else
	{
		if(move_uploaded_file($_FILES["image"]["tmp_name"], $target_file))
		{
			$imagename = basename($_FILES["image"]["name"]);
			$msg = "The file " . basename($_FILES["image"]["name"])." has been uploaded.";
			header("Location:addbook.php?msg=$msg&imagename=$imagename&uploadOk=$uploadOk&menu1=$menu1&menu2=$menu2&menu3=$menu3&menu4=$menu4&bookname=$bookname&bookno=$bookno&bookprice=$bookprice");
		}
		else
		{
			$uploadOk=0;
			$msgerr =  "Sorry! File is not upload successfully.";
			header("Location:addbook.php?msgerr=$msgerr&uploadOk=$uploadOk&menu1=$menu1&menu2=$menu2&menu3=$menu3&menu4=$menu4&bookname=$bookname&bookno=$bookno&bookprice=$bookprice");
		}
	}
}	
?>
