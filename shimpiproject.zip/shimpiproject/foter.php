<?php
include("connectioncode.php");
?>
<!DOCTYPE html>
<html>
<head>
	<style>
		.footer
		{
			background-color: #2b2828;
			height: 200px;
			width: 100%;
		}
		.about
		{
			margin-left:120px;
		}
		.connect
		{
			margin-left:520px;
			margin-top: -85px; 
			text-decoration: none;
		}
		.feedback
		{
			margin-left:920px;
			margin-top: -100px;
		}
		.feedback input[type=email], select
		{
			background-color: grey;
			color: black;
			width: 250px;

		}
		::placeholder 
		{
  			color: black;
 			opacity: 1; /* Firefox */
		}

		:-ms-input-placeholder 
		{ /* Internet Explorer 10-11 */
			color: black;
		}

		::-ms-input-placeholder 
		{ /* Microsoft Edge */
 			color: black;
		}
		.feedback textarea
		{
			background-color: grey;
			color: black;
		} 
		.feedback input[type=submit]
		{
			background-color: grey;
			color: black;
			border-radius: 4px;
  			cursor: pointer;
  			width: 100px;
		}
		.feedback input[type=submit]:hover 
		{
  			background-color: #45a049;
		}
		
	</style>
</head>
<body>
	<?php
	$msgerr="";
$email=$comment="";
if ($_SERVER["REQUEST_METHOD"]=="POST")
{
 $email=test_input($_POST["email"]);
 $comment=test_input($_POST["comment"]);

 $sql="insert into feedback(email,comment) values(\"$email\",\"$comment\")";
 	if(mysqli_query($conn,$sql))
    	{
            $msg = "Comment successfully";
            $email="";
            $comment="";
  
        }
        else
        {
            $msgerr = "Registration does not successfully";                        
        }
}


function test_input($data)
    {
      $data=trim($data);
      $data=stripcslashes($data);
      $data=htmlspecialchars($data);
      return $data; 
    }




	?>
	<div class="footer">
		<div class="about">
			<font style="font-size:20px; color: white" face="calibri">About us</font>
			<p style="font-size: 10px; color: lightblue; font-family:calibri"> Our company is a comprehensive Online Bookstore for<br> 
																			   both Books and other products of every point of knowledge.<br>
																			   Our philosophy is based on information,communication	and education,<br> 
																			   which feel should be balanced out with a daily dose of knowledge,<br>
																			   wisdom,understanding.</p>
		</div>
		<div class="connect">
			<font style="font-size:20px; color: white" face="calibri">Keep Connected</font><br>
			<a href=""><font style="font-size:20px; color: white ; color: lightblue" face="calibri">Facebook</font><br></a>
			<a href=""><font style="font-size:20px; color: white;color: lightblue" face="calibri">Instagram</font><br></a>
			<a href=""><font style="font-size:20px; color: white;color: lightblue" face="calibri">Twitter</font></a>
		</div>
		<div class="feedback">
			<form method="post"  onSubmit="alert('Thank you for your feedback.');">
				<font style="font-size:20px; color: white" face="calibri">FeedBack</font><br>
				<input type="email" name="email" placeholder="Enter Your Email" required=""  ><br><br>
				<textarea cols="25" rows="3" name="comment" placeholder="Comment........" style="line-height: 20px" required=""></textarea><br>
				<input type="submit" value="Submit">
			</form>
		</div>
	</div>
</body>
</html>
