<?php
session_start();
if(!isset($_SESSION["userid"])){ //If session not registered
header("location:login.php"); // Redirect to login.php page
}
else
{
	$now=time();
	if($now > $_SESSION['expire'])
	{
		session_destroy();
		header("Location:login.php");
	}
}
?>
<?php
include("connectioncode.php");
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>View/Edit</title>
<link rel="stylesheet" type="text/css" href="css/style.css"/>
<script type="text/javascript">

function changesDone(obj1, obj2, obj3, obj4, obj5, obj6, obj7, obj8 ,obj9){
	document.viewForm.h1.value = obj1.value;
	document.viewForm.h2.value = obj2.value;
	document.viewForm.h3.value = obj3.value;
	document.viewForm.h4.value = obj4.value;
	document.viewForm.h5.value = obj5.value;
	document.viewForm.h6.value = obj6.value;
	document.viewForm.h7.value = obj7.value;
	document.viewForm.h8.value = obj8.value;
	document.viewForm.h9.value = obj9;

	document.viewForm.action = "updateBook.php";
	document.viewForm.submit();
}
 
 function uploadFile(obj1){	
	document.viewForm.action = "uploadbookimage.php?uploadOk=0&msgerr="+"&msg="+"&h9="+obj1;
	document.viewForm.submit();
}

function delete_publisher(obj1){
	var agree = confirm('Are you absolutely sure you want to delete?');
	if(agree){
		document.viewForm.h1.value = obj1;
		document.viewForm.action = "deletebook.php";
		document.viewForm.submit();
		true;
	}
	else{
		false;
	}
}
</script>
</head>
<body>
<?php
$succMsg = $_GET["succMsg"];
if($succMsg==null){
	$succMsg="";
}

$failMsg = $_GET["failMsg"];
if($failMsg==null){
	$failMsg="";
}

?>
<div class="main_contain">
	<div class="header">
		<img src="http://localhost/shimpiproject/book_images/Logo.png"  height="74" width="140" alt="logo" align="absmiddle"/><B style="margin-left:20px;"><font face="calibiri" size="+3" color="#FFFFFF">Admin View</font></B>
	</div>
	<div class="main_common" style="width:1500px">
		<div class="login_div">
			<div align="right">
				<a href="adminhomepage.php"><img src="http://localhost/shimpiproject/book_images/home.jpg" height="50" width="50" alt="home" title="Home" align="absmiddle"></a>&nbsp;&nbsp;&nbsp;&nbsp;||&nbsp;&nbsp;&nbsp;&nbsp;<a href="addbook.php?uploadOk=0&msgerr=&menu1=&menu2=&menu3=&menu4=&bookname=&bookno=&bookprice="><img src="http://localhost/shimpiproject/book_images/bk.png" height="50" width="70" alt="back" title="Go Back One Page" align="absmiddle"></a>&nbsp;&nbsp;&nbsp;&nbsp;||&nbsp;&nbsp;&nbsp;&nbsp;<B><font face="Times New Roman" size="4">Welcome:</font>&nbsp;<font face="Times New Roman" size="4" color="#000099"><?php echo $_SESSION["userid"];?><bean:write name="LoginForm" property="id"/></font></B>&nbsp;&nbsp;&nbsp;&nbsp;||&nbsp;&nbsp;&nbsp;&nbsp;<a href="logout.php"><b><font size="3">Logout</font></b></a>&nbsp;&nbsp;&nbsp;&nbsp;		
			</div>
			<div align="center">
				<b><font face="calibiri" size="+2" color="#000099">View Book </font></b><br><br><br><br>
				<div align="center">
					<B><font color="#FF0000" size=2.5><?php echo $failMsg;?></font></B>
					<B><font color="#347235" size=2.5><?php echo $succMsg;?></font></B>
					<br><br>
				</div>
				<form name="viewForm" action="view_editBook.php" method="post">
					<input type="hidden" name="h1" value="">
					<input type="hidden" name="h2" value="">
					<input type="hidden" name="h3" value="">
					<input type="hidden" name="h4" value="">
					<input type="hidden" name="h5" value="">
					<input type="hidden" name="h6" value="">
					<input type="hidden" name="h7" value="">
					<input type="hidden" name="h8" value="">
					<input type="hidden" name="h9" value="">
					<table border=0>
					<?php
						$sql1 = "select * from addcategory";
						$sql2= "select * from addauthor";
						$sql3 = "select * from addpublisher";
						$sql = "select * from addbook";
						$result=mysqli_query($conn,$sql);						

						if(mysqli_num_rows($result)<0){
					?>
						<tr>
							<td align="center" valign="middle" colspan=4>
								<b><font size="3" face="Times New Roman">No Book records are available.</font></b><br><br><br><br>
							</td>
						</tr>
					<?php		
						}
						else{
					?>
							<tr>
								<th align="center" valign="middle">
									<b><font face="Times New Roman" size="3">Books</font></b>
								</th>
							</tr>
					<?php		
							$i=1;
							while($row= mysqli_fetch_array($result)){
								$id = $row['id'];
								$cid = $row['categoryid'];
								$aid = $row['authorid'];
								$pid = $row['publisherid'];
								$lang = $row['language'];
								$bookname = $row['bookname'];
								$bookno = $row['bookno'];
								$bookprice = $row['bookprice'];
								$fname = $row['imagename'];

								$result1=mysqli_query($conn,$sql1);
								$result2=mysqli_query($conn,$sql2);
								$result3=mysqli_query($conn,$sql3);
					?>
								<tr>
									<td align="center" valign="middle">
										<input type="hidden" name="hideCategory<?php echo $i; ?>" value="<?php echo $cid;?>">
										<input type="hidden" name="hideAuthor<?php echo $i; ?>" value="<?php echo $aid;?>">
										<input type="hidden" name="hidePublisher<?php echo $i; ?>" value="<?php echo $pid;?>">
										<input type="hidden" name="hideLanguage<?php echo $i; ?>" value="<?php echo $language;?>">
										<input type="hidden" name="hideBookname<?php echo $i; ?>" value="<?php echo $bookname;?>">
										<input type="hidden" name="hideBookno<?php echo $i; ?>" value="<?php echo $bookno;?>">
										<input type="hidden" name="hideBookprice<?php echo $i; ?>" value="<?php echo $bookprice;?>">
										<input type="hidden" name="hideFilename<?php echo $i; ?>" value="<?php echo $fname;?>">
										<select name="category<?php echo $i; ?>"> 
											<option value="0">Select Category:</option>
											<?php if(mysqli_num_rows($result1)>0){
												while($row2= mysqli_fetch_array($result1)){ 
													if($row2['id']==$cid){
													?>
														<option value="<?php echo $row2['id']; ?>" selected><?php echo $row2['categoryname']; ?></option>
													<?php	
													}
													else{
													?>
														<option value="<?php echo $row2['id']; ?>"><?php echo $row2['categoryname']; ?></option>
													<?php	
													}													
										 		}
											}
									 		?>
										</select>
										<select name="author<?php echo $i; ?>"> 
											<option value="0">Select Author:</option>
											<?php if(mysqli_num_rows($result2)>0){
												while($row3= mysqli_fetch_array($result2)){ 
													if($row3['id']==$aid){
													?>
														<option value="<?php echo $row3['id']; ?>" selected><?php echo $row3['authorname']; ?></option>
													<?php	
													}
													else{
													?>
														<option value="<?php echo $row3['id']; ?>"><?php echo $row3['authorname']; ?></option>
													<?php	
													}													
										 		}
											}
									 		?>
										</select>
										<select name="publisher<?php echo $i; ?>">
											<option value="0">Select Publisher:</option>
											<?php if(mysqli_num_rows($result3)>0){
												while($row4= mysqli_fetch_array($result3)){ 
													if($row4['id']==$pid){
													?>
														<option value="<?php echo $row4['id']; ?>" selected><?php echo $row4['publishername']; ?></option>
													<?php	
													}
													else{
													?>
														<option value="<?php echo $row4['id']; ?>"><?php echo $row4['publishername']; ?></option>
													<?php	
													}													
										 		}
											}
									 		?>
										</select>
										<Select name="language<?php echo $i; ?>">
											<?php
												if($lang=="0"){
											?>
													<option value="0" selected>Select Language:</option>
											<?php	
												}
												else{
											?>
													<option value="0">Select Language:</option>
											<?php
												}
												if ($lang=="hindi") {
											?>
													<option value="hindi" selected>Hindi</option>										
											<?php	# code...
												}
												else{
											?>
													<option value="hindi">Hindi</option>
											<?php	
												}													
												if ($lang=="english") {
											?>
													<option value="english" selected>English</option>										
											<?php	# code...
												}
												else{
											?>
													<option value="english">English</option>
											<?php	
												}												
												if ($lang=="marathi") {
											?>
													<option value="marathi" selected>Marathi</option>										
											<?php	# code...
												}
												else{
											?>
													<option value="marathi">Marathi</option>
											<?php	
												}											
												if ($lang=="gujrati") {
											?>
													<option value="gujrati" selected>Gujrati</option>										
											<?php	# code...
												}
												else{
											?>
													<option value="gujrati">Gujrati</option>
											<?php	
												}											
												if ($lang=="telugu") {
											?>
													<option value="telugu" selected>Telugu</option>										
											<?php	# code...
												}
												else{
											?>
													<option value="telugu">Telugu</option>
											<?php	
												}									
												if ($lang=="tamil") {
											?>
													<option value="tamil" selected>Tamil</option>										
											<?php	# code...
												}
												else{
											?>
													<option value="tamil">Tamil</option>
											<?php	
												}									
												if ($lang=="malyalam") {
											?>
													<option value="malyalam" selected>Malyalam</option>										
											<?php	# code...
												}
												else{
											?>
													<option value="malyalam">Malyalam</option>
											<?php	
												}
											?>
										</Select>	
										<input type="text" name="bookname<?php echo $i; ?>" value="<?php echo $bookname;?>" size="20" maxlength="20" >
										<input type="text" name="bookno<?php echo $i; ?>" value="<?php echo $bookno;?>" size="20" maxlength="20" >
										<input type="text" name="bookprice<?php echo $i; ?>" value="<?php echo $bookprice;?>" size="20" maxlength="20" >
										<input type="text" name="fn<?php echo $i; ?>" value="<?php echo $fname;?>" size="20" maxlength="20" disabled><br><br>
									</td>
									<td align="center" valign="middle">
										&nbsp;<input type="submit" name="upload<?php echo $i; ?>" value="Upload" onclick="uploadFile('<?php echo $id; ?>');"><br><br>
									</td>	
									<td align="center" valign="middle">
										&nbsp;<input type="submit" name="done<?php echo $i; ?>" value="Done" onclick="changesDone(document.viewForm.category<?php echo $i; ?>,document.viewForm.author<?php echo $i; ?>,document.viewForm.publisher<?php echo $i; ?>,document.viewForm.language<?php echo $i; ?>,document.viewForm.bookname<?php echo $i; ?>,document.viewForm.bookno<?php echo $i; ?>,document.viewForm.bookprice<?php echo $i; ?>,document.viewForm.fn<?php echo $i; ?>,'<?php echo $id; ?>');"><br><br>
									</td>
									<td align="center" valign="middle">
										&nbsp;<input type="submit" value="Delete" onclick="return delete_book('<?php echo $id; ?>');"><br><br>
									</td>
								</tr>
					<?php		
								$i++;	
							}
						}
					?>
						
					</table>
				</form><br><br>
			</div>
		</div>
	</div>
	<div class="footer">
		<div class="footerLogo1">
			Developed by
		</div>
		<div class="footerLogo2">
			<img src="http://localhost/shimpiproject/book_images/Logo.png">		
		</div>
	</div>
</div>		
</body>
</html>
<?php
mysqli_close($conn);
?>