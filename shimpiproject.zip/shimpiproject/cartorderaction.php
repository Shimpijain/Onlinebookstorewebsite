<?php
session_start();
include("connectioncode.php");

	
if(isset($_SESSION["loggedmail"])){
	$mailid = $_SESSION["loggedmail"];
}

$fullname=$contactno=$address=$state=$city=$pincode=$msgerr="";

function filtername($field)
  {
    $field=filter_var(trim($field),FILTER_SANITIZE_STRING);
    if(filter_var($field,FILTER_VALIDATE_REGEXP,array("options"=>array("regexp"=>"/^[a-zA-Z\s]+$/"))))
    {
      return $field;
    }
    else
    {
      return FALSE;
    }
  }

  function filterno($field)
  {
    $field=filter_var(trim($field),FILTER_SANITIZE_STRING);
    if(filter_var($field,FILTER_VALIDATE_REGEXP,array("options"=>array("regexp"=>"/^[0-9\s]+$/"))))
    {
      return $field;
    }
    else
    {
      return FALSE;
    }
  }

  function test_input($data)
    {
      $data=trim($data);
      $data=stripcslashes($data);
      $data=htmlspecialchars($data);
      return $data; 
    }

if($_SERVER["REQUEST_METHOD"]=="POST"){	
	$flag=$_POST["status"];
	$fullname=test_input($_POST["fullname"]);
	$contactno=test_input($_POST["contactno"]);
	$address=test_input($_POST["address"]);
	$state=test_input($_POST["state"]);
	$city=test_input($_POST["city"]);
	$pincode=test_input($_POST["pincode"]);

	if(filtername($fullname)==FALSE){
		$msgerr = "Please enter the correct value";
		header("Location:buycart.php?msgerr=$msgerr");
	}
	else if(filterno($contactno)==FALSE){
		$msgerr = "Please enter the correct value";
		header("Location:buycart.php?msgerr=$msgerr");
	}
	else if(strlen($contactno)>10){
		$msgerr = "Please enter the correct value";	
		header("Location:buycart.php?msgerr=$msgerr");
	}
	else if(filtername($state)==FALSE){
		$msgerr = "Please enter the correct value";
		header("Location:buycart.php?msgerr=$msgerr");
	}
	else if(filtername($city)==FALSE){
		$msgerr = "Please enter the correct value";	
		header("Location:buycart.php?msgerr=$msgerr");
	}
	else if(filterno($pincode)==FALSE){
		$msgerr = "Please enter the correct value";		
		header("Location:buycart.php?msgerr=$msgerr");
	}
	else if(strlen($pincode)>6){
		$msgerr = "Please enter the correct value";	
		header("Location:buycart.php?msgerr=$msgerr");
	}
	else{		
		if($flag==false){
			$sql = "insert into userinfo(emailid,fullname,contactno,address,state,city,pincode)values(\"$mailid\",\"$fullname\",\"$contactno\",\"$address\",\"$state\",\"$city\",\"$pincode\")";
		}
		else{
			$sql = "update userinfo set fullname=\"$fullname\", contactno=\"$contactno\", address=\"$address\", state=\"$state\", city=\"$city\", pincode=\"$pincode\" where emailid=\"$mailid\"";
		}

		if(mysqli_query($conn,$sql)){
			$msg="Success";
			header("Location:buynow.php");
		}
		else{
			$msgerr = "Order does not place successfully";	
			header("Location:buycart.php?msgerr=$msgerr");
		}
	}
}
mysqli_close($conn);

?>