<?php
session_start();
include("connectioncode.php"); 
?>
<!DOCTYPE html>
<html>
<head>

</head>
<body>
	<center>
		<a href="index.php">
		<img src="http://localhost/shimpiproject/book_images/Logo.png" height="60" width="100"></a>
		<div style="height: 30px;width: 100%;background-color: lightblue;text-align: center;"><font size="4" color="black" style="margin-top: 10px;"><b>Thankyou for your Order. Your order will be soon delivered</b></p></div><br>		
	</center>
	
	<?php
	$mailid=$orderid=$imagename=$bookname="";
	if(isset($_SESSION["loggedmail"]))
		{
			$mailid = $_SESSION["loggedmail"];
			$orderid = $_SESSION["orderno"];
		}
		
		$sql="select * from buynow where orderid=\"$orderid\"";
		$result=mysqli_query($conn,$sql);
		if(mysqli_num_rows($result)>0)
		{
			while($row= mysqli_fetch_array($result))
			{
				$totalprice=$row["totalprice"];
				$orderdate=$row["orderdate"];

				$sql1="select * from purchaseitem where orderid=\"$orderid\"";
				$result1=mysqli_query($conn, $sql1);
				if(mysqli_num_rows($result1)>0)
				{
					while($row1= mysqli_fetch_array($result1))
					{
						$bookno = $row1['bookno'];
						$bookprice = $row1['bookprice'];
						$paymentmethod = $row1['paymentmethod'];

						$sql2="select * from addbook where bookno=\"$bookno\"";
						$result2=mysqli_query($conn, $sql2);
						if(mysqli_num_rows($result2)>0)
						{
							while($row2= mysqli_fetch_array($result2))
							{
								$imagename = $row2['imagename'];
								$bookname = $row2['bookname'];
				
							}
						}
						else{
							$imagename="";
							$bookname="";
						}	

				
				
			?>
				<font size="5">Your order id:</font>
				<?php echo $orderid; ?>
				<br>
				<font size="5">Your total price:</font>
				<?php echo $totalprice; ?>
				<br>
				<font size="5">Order date:</font>
				<?php echo $orderdate; ?>
				<br>
				<font size="5">Order Bookno:</font>
				<?php echo $bookno; ?>
				<br>
				<font size="5">Book Price:</font>
				<?php echo $bookprice; ?>
				<br>
				<font size="5">Order payment method:</font>
				<?php echo $paymentmethod; ?>
				<div style="margin-top: -150px;float: right;"><br>
				<img src="http://localhost/shimpiproject/book_images/<?php echo $imagename; ?>" height="300" width="300">
			</div><br>
				<font size="5">Book Name:</font>
				<?php echo $bookname; ?>
				<br><br>	<br><br><br><br><br><br><br>
				<div style="height: 2px;width: 100%;background-color: black"></div><br><br>
			<?php
			}
			} 
		}
	}

	else
	{
		echo "No records";
	}
	?>
	<a href="index.php"><center><button style="width: 250px;height: 50px;background-color:black;color: white;font-size: 20px">Continue For Shopping</button></center></a>
</body>
</html>