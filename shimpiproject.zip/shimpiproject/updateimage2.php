<?php
	include("connectioncode.php");
?>
<?php
	$succMsg=$failMsg="";
	$fname=$_GET["fname"];
	$id=$_GET["h3"];
	$sql="update addpublisher set filename=\"$fname\" WHERE id = \"$id\"" ;
	if(mysqli_query($conn,$sql))
	{
		$succMsg = "File Updated Successfully";
		header("Location:view_editPublisher.php?succMsg=$succMsg&failMsg=$failMsg");
	}
	else
	{
		$failMsg = "File does not Updated Successfully";
		header("Location:view_editPublisher.php?failMsg=$failMsg&succMsg=$succMsg");
	}
	mysqli_close($conn);
?>