<style type="text/css">
	.btn
	{
		background-color: orange;
	}
</style>

<a href="index.php" style="float: right;font-size:30px ">Home</a>
<?php 
include("connectioncode.php");
?>

<?php 
$aname=$pname=$language=$bkname=$bkno=$bkprice=$bkimage=$authid=$pubid="";
		$sql="select * from addtocart ";
		$result=mysqli_query($conn,$sql);

		if(mysqli_num_rows($result)>0)
		{
			while($row= mysqli_fetch_array($result))
			{
				$authid = $row['authorid'];
				$authorsql = "select authorname from addauthor where id=\"$authid\"";
				$authres = mysqli_query($conn,$authorsql);
				if(mysqli_num_rows($authres)>0)
				{
					while($authrow= mysqli_fetch_array($authres))
					{
						$aname = $authrow['authorname'];
					}	
				}
				else
				{
					$aname="";
				}
				$pubid = $row['publisherid'];
				$pubsql = "select publishername from addpublisher where id=\"$pubid\"";
				$pubres = mysqli_query($conn,$pubsql);
				if(mysqli_num_rows($pubres)>0)
				{
					while($pubrow= mysqli_fetch_array($pubres))
					{
						$pname = $pubrow['publishername'];
					}	
				}
				else{
					$pname="";
				}
				$language = $row['language'];
				$bkname = $row['bookname'];
				$bkno = $row['bookno'];
				$bkprice = $row['bookprice'];
				$bkimage = $row['imagename'];
	?>
				<img src="http://localhost/shimpiproject/book_images/<?php echo $bkimage; ?>" width="300" height="300">
				<div style="margin-left: 300px; margin-top: -300px">
				<label>Author Name:</label>
				<?php
				echo $aname;
				?>
				<br>
				<label>Publisher Name:</label>
				<?php
				echo $pname;
				?>
				<br>
				<label>Language:</label>
				<?php
				echo $language;
				?>
				<br>
				<label>Book Name:</label>
				<?php
				echo $bkname;
				?>
				<br>
				<label>Book Number:</label>
				<?php
				echo $bkno;
				?>
				<br>
				<label>Book Price:</label>
				<?php
				echo $bkprice;
				?>&#8377;
				<br><br>

				<?php
				if(!isset($_SESSION["loggedmail"])){
				?>
				<?php	
				}
				else{
				?>
				<?php	
				}
				?>
				<br><br><br><br><br><br>
				<br><br><br><br><br><br>
				</div>
				<div style="height: 1px;width: 100%;background-color: grey"></div><br>
	<?php
			}			
		}
		else{
		?>
			<div style="margin-left: 300px; margin-top: -300px">
				No Books Available.
			</div>	
		<?php	
		}
	?>
	<center><a href="buycart.php?msgerr="  style="text-decoration: none;font-size: 2px;color: white;"><button style="background-color: black;color: white;font-size: 22px"> Buy Now </button></a></center>