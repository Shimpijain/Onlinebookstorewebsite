<!DOCTYPE html>
<html>
<head>
	<style>
		.btn
		{
			background-color: lightblue;
		}
		.btn:hover
		{
			 background-color: grey;
		}
		input[type=submit] 
		{
			background-color: #ff9900;
		}
		input[type=submit]:hover 
		{
 		 	background-color: #cc7a00;
		}
		input[type=text], select 
		{
			border-color: lightblue;
		}
	</style>
</head>
<body>
	<div>
		<center>
			<a href="index.php"><img src="http://localhost/shimpiproject/book_images/Logo.png" height="70" width="90" style="margin-left: -45px;text-decoration: none">
			<h3 style="margin-top: -50px;margin-left: 100px;">Sharvi.in</h3></a>
		</center><br>
		<center>
			<form style="border: 1px solid #d0e1e1; width: 25%; height: 250px" action="" method="post">
				<table>
					<tr>
						<td><font style="font-size: 30px; font-family:Amazon Ember,Arial,sans-serif;" >Authentication<br> required</font>
							<br><font style="font-size: 15px; font-family:Amazon Ember,Arial,sans-serif;line-height: 25px" >For your security, we need to authenticate your request. We've sent an OTP to the email . Please enter it below to complete verification.</font></td>
					</tr>
					<tr>
						<td><br><font style="font-size: 18px;font-family:Amazon Ember,Arial,sans-serif; ">Email OTP</font></td>
					</tr>
					<tr>
						<td>
							<input type="text" name="otp" placeholder="Enter Your OTP" style="width: 250px;">
						</td>
					</tr>
					<tr>
						<td><br>
							<input type="submit" name="" value="Continue" style="width: 300px;margin-left: -10px;height: 30px; cursor: pointer;">
						</td>
					</tr>
					<tr>
						<td><br>
							<center><a href="" style="text-decoration: none;color: #4775d1;font-family:Amazon Ember,Arial,sans-serif;font-size: 14px;margin-left: -35px">Resend OTP</a></center>
						</td>
					</tr>
				</table>
			</form><br><br>
		</center>
	</div>
</body>
</html>