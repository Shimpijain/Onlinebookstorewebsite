<?php
	include("connectioncode.php");
?>
<?php
	$succMsg=$failMsg="";
	$publisher=$_POST["h1"];
	$id=$_POST["h3"];
	$fn = $_POST["h2"];
	//echo "$publisher";
	//echo "$id";
	$sql= "update addpublisher set publishername=\"$publisher\", filename=\"$fn\" where id=\"$id\"";	
	if(mysqli_query($conn,$sql))
	{
		$succMsg="Successfully updated";
		header("Location:view_editPublisher.php?succMsg=$succMsg&failMsg=$failMsg");
	}
	else
	{
		$failMsg= "Updation Failure";
		header("Location:view_editPublisher.php?succMsg=$succMsg&failMsg=$failMsg");
	}
	mysqli_close($conn);
?>