<?php                               
include("connectioncode.php");
$err="";
$menu1=$_POST["menu1"];
$menu2=$_POST["menu2"];
$menu3=$_POST["menu3"];
$menu4=$_POST["menu4"];

if ($menu1=="0" && $menu2=="0" && $menu3=="0" && $menu4=="0") 
{
	$msgerr = "Please Select any one of the option.";
	header("Location:bookstock.php?msgerr=$msgerr");
}
else if($menu1!="0" && $menu2=="0" && $menu3=="0" && $menu4=="0"){

}
else if($menu1=="0" && $menu2!="0" && $menu3=="0" && $menu4=="0"){

}
else if($menu1=="0" && $menu2=="0" && $menu3!="0" && $menu4=="0"){

}	
else if($menu1=="0" && $menu2=="0" && $menu3=="0" && $menu4!="0"){

}
else if($menu1!="0" && $menu2!="0" && $menu3=="0" && $menu4=="0"){

}
else if($menu1!="0" && $menu2=="0" && $menu3!="0" && $menu4=="0"){

}
else if($menu1!="0" && $menu2=="0" && $menu3=="0" && $menu4!="0"){

}
else if($menu1=="0" && $menu2!="0" && $menu3!="0" && $menu4=="0"){

}
else if($menu1=="0" && $menu2!="0" && $menu3=="0" && $menu4!="0"){

}
else if($menu1=="0" && $menu2=="0" && $menu3!="0" && $menu4!="0"){

}
else if($menu1!="0" && $menu2!="0" && $menu3!="0" && $menu4=="0"){

}
else if($menu1=="0" && $menu2!="0" && $menu3!="0" && $menu4!="0"){

}
else if($menu1!="0" && $menu2!="0" && $menu3!="0" && $menu4!="0"){

}
mysqli_close($conn);
?>