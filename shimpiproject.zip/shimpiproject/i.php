<?php
include("connectioncode.php");
?>
<!DOCTYPE html>
<html>
<head>
	<title> SHRAVI ONLINE BOOK STORE.in</title>
	<meta name="viewport"
	content="width=device-width,initial-scale=1">
	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  	<script type="text/javascript" src="screenRes.js"></script>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<style>
		.head
		{
			padding-top: 10px;
		}
		.logo
		{
			padding-left: 1250px;
			padding-top: -100px;
		}
		.search
		{
			margin:-100px;
		padding-left:1000px;
		height: 90px;

		}
		.search input
		{
			height: 30px;
		}
		.image
		{
     		display: inline;
     		padding: 10px;
     		cursor: pointer;
 		}
 		.author
 		{
 			cursor: pointer;
 		}
 		.publisher
 		{
 			cursor: pointer;
 		}
 		.language
 		{
 			cursor: pointer;
 		}
 		.leftside
 		{
 			float: left;
 			border: none;
 		}
 		.rightside
 		{
 			float: right;
 		}
 		#myBtn 
		{
		  display: none;
		  position: fixed;
		  bottom: 20px;
		  right: 30px;
		  z-index: 99;
		  font-size: 18px;
		  border: none;
		  outline: none;
		  background-color: black;
		  color: white;
		  cursor: pointer;
		  padding: 15px;
		  border-radius: 4px;
		}
		#myBtn:hover {
		  background-color: #555;
		}
	</style>
</head>
<body>
	<button onclick="topFunction()" id="myBtn" title="Go to top">Top</button>
	<div><?php include("menubar.php"); ?></div>
	<?php include("header.html"); ?>
	<marquee><font face="arabic typesetting"> WELCOME TO SHRAVI ONLINE BOOK STORE HAVE A GOOD CHOICE</font></marquee>
	<div style="background-color: grey;height: 20px; margin-top:-20px">
	<h4 style="background-color: white">Books</h4>
   	<a href="newrealise.php"><label class="Book" style="cursor: pointer; color: blue; margin-right: 100px"> &nbsp;NewRealise</label></a>
   	<a href="#"><label class="Book"style="cursor: pointer;color: blue; margin-right: 150px"> TextBooks </label></a>
  	<a href="#"><label class="Book"style="cursor: pointer;color: blue; margin-right: 150px"> Best Seller </label></a>
  	<a href="#"><label class="Book"style="cursor: pointer;color: blue;margin-right: 150px"> Children's&YoungAdult </label></a>
  	<a href="#"><label class="Book"style="cursor: pointer;color: blue;margin-right: 150px"> Advance Search </label></a>
  	</div>
  	<br>
  	<br>
  	<div>
  	<a href="#"><img src="http://localhost/shimpiproject/book_images/a.jpg" style="height:100px ;width:80px;margin-right: 100px"></a>
  	<a href="#"><img src="http://localhost/shimpiproject/book_images/b.jpg" style="height:100px ;width:80px;margin-right: 135px "></a>
  	<a href="#"><img src="http://localhost/shimpiproject/book_images/c.jpg" style="height:100px ;width:80px;margin-right: 180px"></a>
  	<a href="#"><img src="http://localhost/shimpiproject/book_images/d.jpg" style="height:100px ;width:80px;margin-right: 150px"></a>
  	</div>
  	<br><br>
  	<div style="background-color: lightgrey; width: 1350px; height: 2px ;float: left;" ></div>
	<br>
	<br>
	<h2> Shop By Gerne</h2>
	 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

	 	<?php
			$sql ="select * from addcategory";
			$result= mysqli_query($conn, $sql);
			if(mysqli_num_rows($result)>0){
				while($row=mysqli_fetch_array($result))
					{
						$filename=$row['filename'];
		?>	
						<a href=""><img src="http://localhost/shimpiproject/book_images/category/<?php echo $filename; ?>"></a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

				<?php
					}
			}		
		?>		
  	<br>
  	 <div style="background-color: lightgrey; width: 1350px; height: 2px ;float: left;" ></div>
  	 <br>
  	<div>
  		<div class="leftside" style="height:2200px;width:260px;background-color: transparent;">
  			<br>
			<label style="color: grey; font-size: 20px"> Show Results For-</label>
			<table>
					<tr>
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="">Adventure</a>
					<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<a href="">Biographies</a>
					<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<a href="">Children's &young Adult</a>
					<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<a href="">TextBooks</a>
					<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<a href="">Romance</a>
					<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<a href="">Authore Books</a>
					<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<a href="">Indian Languages Books</a>
					<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<a href="">Science</a>
					<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<a href="">Computer's</a>
					<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<a href="">Comics</a>
					</tr>
			</table>
		</div>
		<center>
			<h1>
				<font size="52" color="red" face="Brush Script MT">
				Featured & Series Authors
				</font>
 			</h1>
		</center>
					<?php
						$sql ="select * from addauthor where id between 0 and 7";
						$result= mysqli_query($conn, $sql);
						if(mysqli_num_rows($result)>0){
							while($row=mysqli_fetch_array($result))
								{
									$filename=$row['filename'];
					?>	
						<a href=""><img class="author" src="http://localhost/shimpiproject/book_images/author/<?php echo $filename; ?>" width="200"></a>
						&nbsp;

						<?php
					}
				}		
			?>
			<a href="" style="margin-left:1000px;">More</a>
			<br><br>
					
					
					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<div style="background-color: lightgrey; width: 1000px; height: 2px ;float: right;" ></div>
			<br><br><br>
			<center>
			<h1>
				<font size="52" color="red" face="Brush Script MT">
				Featured Publishers</font>
			</h1>
		</center>

								<?php
						$sql ="select * from addpublisher  where id between 0 and 6";
						$result= mysqli_query($conn, $sql);
						if(mysqli_num_rows($result)>0){
							while($row=mysqli_fetch_array($result))
								{
									$filename=$row['filename'];
					?>



					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=""><img class="publisher" src="http://localhost/shimpiproject/book_images/publisher/<?php echo $filename; ?>" width="150"></a>
						<?php
					}
				}

			?>	
			<br><br>	

					&nbsp;
		<br>
		<br>
		<div style="background-color: lightgrey; width: 1000px; height: 2px ;float: right;" ></div>
		<center>
			<h1>
				<font size="52" color="black" face="arial">
				Books In Indian Languages
			<div style="background-color: lightgrey; width: 1000px; height: 2px ;float: right;" ></div>

			</h1>
		</center>
		<a href=""><img class="language" src="http://localhost/shimpiproject/book_images/languages1.jpg" width="250"></a>
		<a href=""><img class="language" src="http://localhost/shimpiproject/book_images/english.jpg" width="250"></a>
		<a href=""><img class="language" src="http://localhost/shimpiproject/book_images/languages2.jpg" width="250"></a>
		<a href=""><img class="language" src="http://localhost/shimpiproject/book_images/languages3.jpg" width="250"></a>
		<a href=""><img class="language" src="http://localhost/shimpiproject/book_images/languages4.jpg" width="250"></a>
		<a href=""><img class="language" src="http://localhost/shimpiproject/book_images/languages5.jpg" width="250"></a>
		<a href=""><img class="language" src="http://localhost/shimpiproject/book_images/languages6.jpg" width="250"></a>
		<div style="background-color: lightgrey; width: 1000px; height: 2px ;float: right;" ></div>
  	</div>		
  	</div>
  	<div><marquee><font style="font-size: 20px;" face="chiller">Thanks, for visit my website</font></marquee></div>
  	<div style="line-height: 10px">
  		<font style="font-size: 20px;color: #e68a00; margin-left: 300px">Explore and Buy Books at Shravi India</font><br>
  		<font style="font-size: 15px;color: black;margin-left: 300px">Amazon.in offers you over 10 million titles across categories such as Children’s Books, Business & Economics, Indian Writing and Literature & Fiction.<br>
  		<font style="font-size: 15px;color: black;margin-left: 300px">Reading books is the favourite pastime of many people. If you’re bitten by the book-bug too, then there is a massive collection of books for you to read.</font><br><font style="font-size: 15px;color: black;margin-left: 300px"> From bestsellers to new & future releases, the choices are exhaustive when you shop online at India's Largest Bookstore.</font>
  	</div>
  	<?php include("foter.php"); ?>
	<script>
		var mybutton = document.getElementById("myBtn");
		window.onscroll = function() {scrollFunction()};
		function scrollFunction() {
		  if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
		    mybutton.style.display = "block";
		  } else {
		    mybutton.style.display = "none";
		  }
		}
		function topFunction() {
		  document.body.scrollTop = 0;
		  document.documentElement.scrollTop = 0;
		}
	</script>
</body>    
</html>
<?php
mysqli_close($conn);
?>