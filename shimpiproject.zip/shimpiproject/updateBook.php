<?php
	include("connectioncode.php");
?>
<?php
	$succMsg=$failMsg="";
	$category=$_POST["h1"];
	$author=$_POST["h2"];
	$publisher=$_POST["h3"];
	$language=$_POST["h4"];
	$bookname=$_POST["h5"];
	$bookno=$_POST["h6"];
	$bookprice=$_POST["h7"];
	$fname=$_POST["h8"];
	$id=$_POST["h9"];
	/*echo "$category";
	echo "$author";
	echo "$publisher";
	echo "$language";
	echo "$bookname";
	echo "$bookno";
	echo "$fname";
	echo "$bookprice;"
	*/
	$sql="update addbook set categoryid=\"$category\", authorid=\"$author\", publisherid=\"$publisher\", language=\"$language\", bookname=\"$bookname\", bookno=\"$bookno\", bookprice=\"$bookprice\", imagename=\"$fname\" WHERE id = \"$id\"" ;
	if(mysqli_query($conn,$sql))
	{
		$succMsg = "File Updated Successfully";
		header("Location:view_editBook.php?succMsg=$succMsg&failMsg=$failMsg");
	}
	else
	{
		$failMsg = "File does not Updated Successfully";
		header("Location:view_editBook.php?failMsg=$failMsg&succMsg=$succMsg");
	}
	mysqli_close($conn);
?>