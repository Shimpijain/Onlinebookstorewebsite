<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<style>
		.menu
		{
			position: fixed;
		}
	</style>
</head>
<body>
	<div class="menu">
		<?php include("menubar1.php"); ?>
	</div><br><br><br>
	<h1>
		Results In New Realise----
	</h1>
	<div>
		<?php include("foter.html") ?>
	</div>
</body>
</html>