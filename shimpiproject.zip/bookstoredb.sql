-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 29, 2020 at 06:14 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bookstoredb`
--

-- --------------------------------------------------------

--
-- Table structure for table `addauthor`
--

CREATE TABLE IF NOT EXISTS `addauthor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `authorname` varchar(25) NOT NULL,
  `filename` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=77 ;

--
-- Dumping data for table `addauthor`
--

INSERT INTO `addauthor` (`id`, `authorname`, `filename`) VALUES
(1, 'Chetan bhagat', 'author0.jpg'),
(2, 'jeffrey archer', 'author3.jpg'),
(3, 'robin sharma', 'author4.jpg'),
(4, 'shiva trilogy', 'author5.jpg'),
(5, 'amar chitrakatha', 'author6.jpg'),
(6, 'Agatha Christie', 'author1.jpg'),
(7, 'Paulo Coelho', 'author2.jpg'),
(8, 'Nicholas Sparks', 'nicholous.png'),
(45, 'erin morgenstern', 'erin.png'),
(46, 'erich segal', 'erich.png'),
(47, 'rupi kaur', 'RUPI.png'),
(48, 'Nathuram Gaudse', 'NATHURAM.png'),
(49, 'rahul sankritiyayan', 'RAHUL.png'),
(50, 'sankar', 'SANKAR.png'),
(51, 'savi sharma', 'SAVI.png'),
(52, 'shaheen bhatt', 'SHAEEN.png'),
(53, 'simcha', 'SIMCHA.png'),
(54, 'susan ninan', 'SUSANNINAN.png'),
(55, 'adolf hitler', 'HITLER.png'),
(56, 'albert', 'albert.png'),
(57, 'anne frank', 'ANNE.png'),
(58, 'anup sardesai', 'ANUP.png'),
(59, 'bajarne', 'BAJARNE.png'),
(60, 'Behroz', 'BEHROUZ.png'),
(61, 'dreamtech', 'DREAMRECH.png'),
(62, 'ebalaguruswami', 'BALAGURUSWAMI.png'),
(63, 'fabian', 'FABIAN.png'),
(64, 'Fujico f', 'FUJICO.png'),
(65, 'jacob abbott', 'JECOB.png'),
(66, 'Kogent learning', 'KOGENT.png'),
(67, 'J K Rowling', 'JKROWLING.png'),
(68, 'M Agrawal', 'AMIT.png'),
(69, 'nageshwara', 'NAGESHWARA.png'),
(70, 'pran', 'PRAN.png'),
(71, 'R P jain', 'RPJAIN.png'),
(72, 'R S agrawal', 'RSAGRAWAL.png'),
(73, 'R D sharma', 'RDSHARMA.png'),
(74, 'William Hanna', 'WILLIAM.png'),
(75, 'yashvant', 'YASHVANT.png'),
(76, 'J R R', 'JRR.png');

-- --------------------------------------------------------

--
-- Table structure for table `addbook`
--

CREATE TABLE IF NOT EXISTS `addbook` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `categoryid` varchar(20) NOT NULL,
  `authorid` varchar(20) NOT NULL,
  `publisherid` varchar(20) NOT NULL,
  `language` varchar(20) NOT NULL,
  `bookname` varchar(50) NOT NULL,
  `bookno` varchar(10) NOT NULL,
  `bookprice` varchar(10) NOT NULL,
  `imagename` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=52 ;

--
-- Dumping data for table `addbook`
--

INSERT INTO `addbook` (`id`, `categoryid`, `authorid`, `publisherid`, `language`, `bookname`, `bookno`, `bookprice`, `imagename`) VALUES
(2, '2', '1', '10', 'english', 'The India Girl', '323', '399', 'TheIndianGirl.jpg'),
(3, '2', '1', '10', 'english', 'One Night at the call center', '267', '199', 'one night.jpg'),
(4, '2', '1', '10', 'english', 'Half girlfriend', '260', '251', 'halfgirlfriend.jpg'),
(5, '2', '1', '9', 'english', 'The Girl in Room', '304', '129', 'the girl in room.jpg'),
(6, '2', '2', '11', 'english', 'Old Love', '200', '295', 'old love.jpg'),
(7, '2', '2', '12', 'english', 'beyond reasonable', '300', '299', 'beyond.jpg'),
(8, '2', '2', '12', 'english', 'stuck on you', '24', '395', 'atuck on you.png'),
(9, '2', '46', '11', 'english', 'Love Story', '100', '199', 'love story.jpg'),
(10, '2', '45', '13', 'english', 'the night circus', '101', '295', 'The NIght Circus.jpg'),
(11, '3', '48', '14', 'english', 'why i killed gandhi', '24', '195', 'whyikilledgandhi.jpg'),
(12, '3', '49', '15', 'hindi', 'meri jeevan yatra', '35', '299', 'apj jeevanyatra.jpg'),
(13, '3', '50', '15', 'hindi', 'Vivekanand ki Atamakatha', '54', '199', 'vivekanand.jpg'),
(14, '3', '56', '14', 'english', 'the world as i see it', '76', '299', 'albert.jpg'),
(15, '3', '48', '16', 'hindi', 'Nathuram Gaudse', '75', '295', 'nathuram.jpg'),
(16, '3', '55', '17', 'english', 'adolf hitler', '89', '259', 'hitler.jpg'),
(17, '3', '17', '18', 'english', 'Alexander', '56', '195', 'alex.jpg'),
(18, '3', '52', '19', 'english', 'I''ve never been', '45', '295', 'neverbeen.png'),
(19, '3', '54', '20', 'english', 'Mind Master', '23', '354', 'mindmaster.png'),
(20, '3', '20', '15', 'hindi', 'Chanakya Niti', '74', '325', 'chanakya.jpg'),
(21, '3', '57', '18', 'english', 'The Diary', '98', '295', 'diary.jpg'),
(22, '4', '51', '36', 'english', 'Has a Story', '86', '255', 'story.png'),
(23, '4', '3', '21', 'english', 'The Leader', '48', '299', 'the leader.jpg'),
(24, '4', '3', '21', 'english', 'Megaliving', '85', '199', 'megaliving.jpg'),
(25, '4', '67', '22', 'english', 'Harry porterSorceser', '78', '299', 'harry1.jpg'),
(26, '4', '67', '22', 'english', 'Harry Portar deathly', '94', '295', 'harry2.jpg'),
(27, '4', '67', '22', 'english', 'Harry Portar chamber', '94', '298', 'harry3.jpg'),
(28, '5', '23', '23', 'english', 'The Lord', '547', '195', 'The lord.jpg'),
(29, '19', '64', '24', 'english', 'Doraemon', '956', '295', 'doraemon.jpg'),
(30, '19', '0', '25', 'english', 'Tom and Jerry', '476', '299', 'Tom.jpg'),
(31, '6', '62', '26', 'english', 'C programming', '67', '399', 'c.jpg'),
(32, '6', '75', '27', 'english', 'letus c', '675', '395', 'letus c.jpg'),
(33, '6', '62', '26', 'english', 'C plus plus  ', '543', '395', 'cpp.jpg'),
(34, '6', '59', '28', 'english', 'C plus   programming', '956', '399', 'Cplusplus.jpg'),
(35, '6', '62', '26', 'english', 'java', '76', '458', 'java.jpg'),
(36, '6', '61', '29', 'english', 'java blackbook', '657', '495', 'corejava.jpg'),
(37, '6', '69', '29', 'english', 'java core', '567', '499', 'cjava.jpg'),
(38, '6', '25', '30', 'english', 'vb.net', '68', '395', 'vb.jpg'),
(39, '6', '66', '29', 'english', 'Asp.Net Black book', '234', '399', 'asp.jpg'),
(40, '6', '34', '29', 'english', 'Htmlfive', '55', '299', 'html.jpg'),
(41, '6', '34', '30', 'english', 'css', '564', '395', 'csss.jpg'),
(42, '6', '60', '26', 'english', 'DCN', '22', '499', 'dcn.jpg'),
(43, '6', '68', '2', 'english', 'MCA entrance', '544', '759', 'mca.jpg'),
(44, '5', '72', '31', 'hindi', 'mathematics', '68', '395', 'ms.jpg'),
(45, '5', '73', '32', 'english', 'mathematics', '35', '499', 'm.jpg'),
(46, '19', '70', '33', 'english', 'chacha chaudhary', '689', '199', 'chacha.jpg'),
(48, '19', '0', '34', 'english', 'avenger', '22', '200', 'aven.jpg'),
(49, '19', '0', '18', 'english', 'Jungle Book', '301', '299', 'junglebook.jpg'),
(50, '19', '53', '35', 'english', 'pokemon', '97', '140', 'pokemon.jpg'),
(51, '2', '1', '9', 'hindi', 'twostates', '321', '199', '2 states.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `addcategory`
--

CREATE TABLE IF NOT EXISTS `addcategory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `categoryname` varchar(20) NOT NULL,
  `filename` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `addcategory`
--

INSERT INTO `addcategory` (`id`, `categoryname`, `filename`) VALUES
(2, 'Romantic', 'romantic.png'),
(3, 'Biography', 'biography.png'),
(4, 'Adventure', 'adventure.png'),
(5, 'children', 'children.jpg'),
(6, 'computer', 'computer.png'),
(13, 'business', 'business.jpg'),
(18, 'horror', 'hrrr.jpg'),
(19, 'comic', 'cmic.png');

-- --------------------------------------------------------

--
-- Table structure for table `addpublisher`
--

CREATE TABLE IF NOT EXISTS `addpublisher` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `publishername` varchar(30) NOT NULL,
  `filename` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=37 ;

--
-- Dumping data for table `addpublisher`
--

INSERT INTO `addpublisher` (`id`, `publishername`, `filename`) VALUES
(2, 'arihant', 'publishers2.jpg'),
(3, 'pearson', 'publishers3.jpg'),
(4, 'dreamland', 'publishers1.jpg'),
(5, 'wiley', 'publishers4.jpg'),
(6, 'wolters kluwer', 'publishers5.jpg'),
(7, 'Nicholas Sparks', 'nicholous.png'),
(8, 'grand central', 'GC.png'),
(9, 'chetan bhagat', 'author0.jpg'),
(10, 'Rupa', 'RUPA.png'),
(11, 'Hodder ', 'HODDER.jpg'),
(12, 'jeffrey archer', 'author3.jpg'),
(13, 'Doubleday', 'D.jpg'),
(14, 'Genral Press', 'GP.png'),
(15, 'prabhat prakash', 'PRABHAT.jpg'),
(16, 'pagadas', 'PEGA.png'),
(17, 'mein kampf', 'MEIN.png'),
(18, 'fingerprint', 'FINGER.png'),
(19, 'panguin', 'PENGUIN.png'),
(20, 'hachette', 'HACHE.png'),
(21, 'jaico', 'JAICO.png'),
(22, 'J.K.Rowling', 'JKROWLING.png'),
(23, 'harpercollins', 'HARPER.png'),
(24, 'Shougankukan', 'SHO.png'),
(25, 'Panini', 'PANINI.png'),
(26, 'mc graw hill', 'MCGRAW.png'),
(27, 'BPB', 'BPB.png'),
(28, 'addison', 'ADDI.png'),
(29, 'dreamtech', 'DREAM.png'),
(30, 'laxmi publication', 'LAX.png'),
(31, 's.chand', 'S.png'),
(32, 'Dhanpat rai', 'DHANPAT.png'),
(33, 'dimond', 'DI.png'),
(34, 'marvel', 'MARVEL.png'),
(35, 'scholastic india', 'INI.png'),
(36, 'westland', 'publishers0.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `addtocart`
--

CREATE TABLE IF NOT EXISTS `addtocart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `emailid` varchar(50) NOT NULL,
  `categoryid` int(10) NOT NULL,
  `authorid` varchar(100) NOT NULL,
  `publisherid` varchar(100) NOT NULL,
  `language` varchar(30) NOT NULL,
  `bookname` varchar(50) NOT NULL,
  `bookno` varchar(50) NOT NULL,
  `bookprice` varchar(100) NOT NULL,
  `imagename` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=70 ;

--
-- Dumping data for table `addtocart`
--

INSERT INTO `addtocart` (`id`, `emailid`, `categoryid`, `authorid`, `publisherid`, `language`, `bookname`, `bookno`, `bookprice`, `imagename`) VALUES
(68, '', 19, '70', '33', 'english', 'chacha chaudhary', '689', '199', 'chacha.jpg'),
(69, 'bhawna123@gmail.com', 3, '20', '', 'hindi', 'Chanakya Niti', '74', '325', 'chanakya.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `buynow`
--

CREATE TABLE IF NOT EXISTS `buynow` (
  `orderid` varchar(30) NOT NULL,
  `emailid` varchar(50) NOT NULL,
  `totalprice` int(20) NOT NULL,
  `orderdate` varchar(30) NOT NULL,
  `status` varchar(20) NOT NULL,
  PRIMARY KEY (`orderid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `buynow`
--

INSERT INTO `buynow` (`orderid`, `emailid`, `totalprice`, `orderdate`, `status`) VALUES
('#ODRBh10310', 'bhawna123@gmail.com', 1123, 'Tuesday 28th of January 2020', 'due'),
('#ODRBh1249', 'bhawna123@gmail.com', 2587, 'Tuesday 28th of January 2020', 'due'),
('#ODRra7752', 'ravi@gmail.com', 399, 'Tuesday 28th of January 2020', 'due'),
('#ODRSh11322', 'bhawna123@gmail.com', 399, 'Tuesday 28th of January 2020', 'due'),
('#ODRSh12523', 'bhawna123@gmail.com', 598, 'Tuesday 28th of January 2020', 'due'),
('#ODRSh28894', 'bhawna123@gmail.com', 195, 'Tuesday 28th of January 2020', 'due');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(30) NOT NULL,
  `comment` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=46 ;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `email`, `comment`) VALUES
(1, 'rinkujatav15052002@gmail.con', 'hello'),
(5, 'Satyamnaruka449@gmail.com', 'hello shravi'),
(6, 'rinkujatav@gmail.com', 'hello'),
(7, 'rinkujatav@gmail.com', 'hello'),
(8, 'rinkujatav@gmail.com', 'jhtfy'),
(9, 'rinkujatav@gmail.com', 'jhtfy'),
(10, 'rinkujatav@gmail.com', 'hello'),
(11, 'rinkujatav15052002@gmail.con', 'fhf'),
(12, 'rinkujatav@gmail.com', 'hello'),
(13, 'rinkujatav@gmail.com', 'dshxtdhrf'),
(14, 'rinkujatav@gmail.com', 'rtd6r'),
(15, 'rinkujatav15052002@gmail.com', 'grtsgrtd'),
(16, 'rinkujatav15052002@gmail.com', 'grtsgrtd'),
(17, 'rinkujatav15052002@gmail.con', '65rj5djtymyud yttym'),
(18, 'Satyamnaruka449@gmail.com', 'fghioseuhguenhrgbjthbrivuosrtvhbtjbtrierugwhrewopirbnvbrgierugoeirwjgtrbghtrouhergiorejgkrtgbjthgire'),
(19, '', ''),
(20, '', ''),
(21, '', ''),
(22, '', ''),
(23, '', ''),
(24, '', ''),
(25, '', ''),
(26, '', ''),
(27, '', ''),
(28, '', ''),
(29, '', ''),
(30, '', ''),
(31, '', ''),
(32, '', ''),
(33, '', ''),
(34, '', ''),
(35, '', ''),
(36, '', ''),
(37, '', ''),
(38, '', ''),
(39, '', ''),
(40, '', ''),
(41, '', ''),
(42, '', ''),
(43, '', ''),
(44, '', ''),
(45, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `loginadmin`
--

CREATE TABLE IF NOT EXISTS `loginadmin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `loginadmin`
--

INSERT INTO `loginadmin` (`id`, `username`, `password`) VALUES
(1, 'shimpi jain', '8058249903');

-- --------------------------------------------------------

--
-- Table structure for table `newuser`
--

CREATE TABLE IF NOT EXISTS `newuser` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `newuser`
--

INSERT INTO `newuser` (`id`, `fullname`, `email`, `password`) VALUES
(1, 'bhawna', 'bhawna123@gmail.com', 'Bhawna123456'),
(2, 'Shimpi Jain', 'shampoojainjain@gmail.com', 'Ravi1234'),
(3, 'Shimpi jain', 'shimpi@gmail.com', 'Ravi1234'),
(4, 'Shimpi Jain', 'rinkujatav15052002@gmail.com', 'Ravi1234'),
(5, 'Shimpi Jain', 'shimpijain@gmail.com', 'Ravi1234'),
(6, 'ravi', 'ravi@gmail.com', 'Ravi1234'),
(7, 'sonali', 'sonali@gmail.com', 'Sonali123');

-- --------------------------------------------------------

--
-- Table structure for table `purchaseitem`
--

CREATE TABLE IF NOT EXISTS `purchaseitem` (
  `orderid` varchar(30) NOT NULL,
  `emailid` varchar(50) NOT NULL,
  `bookno` int(20) NOT NULL,
  `bookprice` int(20) NOT NULL,
  `paymentmethod` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchaseitem`
--

INSERT INTO `purchaseitem` (`orderid`, `emailid`, `bookno`, `bookprice`, `paymentmethod`) VALUES
('#ODRSh11322', 'bhawna123@gmail.com', 323, 399, 'cash'),
('#ODRSh28894', 'bhawna123@gmail.com', 24, 195, 'cash'),
('#ODRSh12523', 'bhawna123@gmail.com', 323, 399, 'cash'),
('#ODRSh12523', 'bhawna123@gmail.com', 267, 199, 'cash'),
('#ODRra7752', 'ravi@gmail.com', 323, 399, 'cash'),
('#ODRBh1249', 'bhawna123@gmail.com', 689, 199, 'cash'),
('#ODRBh1249', 'bhawna123@gmail.com', 956, 399, 'cash'),
('#ODRBh1249', 'bhawna123@gmail.com', 74, 325, 'cash'),
('#ODRBh1249', 'bhawna123@gmail.com', 543, 395, 'cash'),
('#ODRBh1249', 'bhawna123@gmail.com', 75, 295, 'cash'),
('#ODRBh1249', 'bhawna123@gmail.com', 260, 251, 'cash'),
('#ODRBh1249', 'bhawna123@gmail.com', 304, 129, 'cash'),
('#ODRBh1249', 'bhawna123@gmail.com', 267, 199, 'cash'),
('#ODRBh1249', 'bhawna123@gmail.com', 24, 395, 'cash'),
('#ODRBh10310', 'bhawna123@gmail.com', 67, 399, 'cash'),
('#ODRBh10310', 'bhawna123@gmail.com', 74, 325, 'cash'),
('#ODRBh10310', 'bhawna123@gmail.com', 956, 399, 'cash');

-- --------------------------------------------------------

--
-- Table structure for table `userinfo`
--

CREATE TABLE IF NOT EXISTS `userinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `emailid` varchar(100) NOT NULL,
  `fullname` varchar(50) NOT NULL,
  `contactno` varchar(10) NOT NULL,
  `address` text NOT NULL,
  `state` varchar(30) NOT NULL,
  `city` varchar(20) NOT NULL,
  `pincode` int(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `userinfo`
--

INSERT INTO `userinfo` (`id`, `emailid`, `fullname`, `contactno`, `address`, `state`, `city`, `pincode`) VALUES
(2, 'bhawna123@gmail.com', 'Bhawna', '7073637888', 'sdjhjsdhf', 'hufbviger', 'gsegohsrtgu', 301411),
(3, 'ravi@gmail.com', 'ravi', '8058249903', 'ojpi9jpi9joij', 'rajasthan', 'kjhvufidhsv', 595948);
